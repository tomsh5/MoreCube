import axios from "axios";

export const dailyFeedbackService = {
  query,
  getById,
  remove,
  save,
  getEmptyFeedback
};

const BASE_URL = "https://dev3.sexence.com:5027";

async function query() {
  try {
    const feedbacks = await axios.get(`${BASE_URL}/dailyFeedbacks`);
    return feedbacks.data;
  } catch (err) {
    console.log("ERROR: cannot find feedbacks", err);
  }
}

async function getById(id) {
  try {
    const feedback = await axios.get(`${BASE_URL}/dailyFeedback/${id}`);
    return feedback.data;
  } catch (err) {
    console.log("ERROR: cannot find feedback", err);
  }
}

async function remove(id) {
  try {
    const res = await axios.get(`${BASE_URL}/delete/${id}`);
    console.log("res:", res.data);
    return res.data;
  } catch (err) {
    console.log(`ERROR: cannot remove feedback ${id}`, err);
    return err;
  }
}

function save(feedback) {
  return feedback.dailyFeedbackId ? _update(feedback) : _add(feedback);
}

async function _update(feedback) {
  try {
    const res = await axios.post(`${BASE_URL}/update`, feedback);
    return res.data;
  } catch (err) {
    console.log(`ERROR: cannot update feedback ${feedback.feedbackId}`, err);
    return err;
  }
}

async function _add(feedback) {
  try {
    const res = await axios.post(`${BASE_URL}/add`, feedback);
    console.log("res:", res.data);
    return res.data;
  } catch (err) {
    console.log("ERROR: cannot add feedback", err);
    return err;
  }
}

function getEmptyFeedback() {
  return {
    createdTs: Date.now(),
    lastUpdatedTs: Date.now(),
    subTitle: "",
    title: ""
  };
}
