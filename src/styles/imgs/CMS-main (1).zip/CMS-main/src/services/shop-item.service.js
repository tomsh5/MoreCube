import axios from "axios";

export const shopItemService = {
  query,
  getById,
  remove,
  save,
  getEmptyShopItem
};

const BASE_URL = "https://dev3.sexence.com:5050";

async function query() {
  try {
    const shopItems = await axios.get(`${BASE_URL}/shopItems`);
    return shopItems.data;
  } catch (err) {
    console.log("ERROR: cannot find shop items", err);
  }
}

async function getById(id) {
  try {
    const shopItem = await axios.get(`${BASE_URL}/shopItem/${id}`);
    return shopItem.data;
  } catch (err) {
    console.log("ERROR: cannot find shop item", err);
  }
}

async function remove(id) {
  try {
    const res = await axios.get(`${BASE_URL}/delete/${id}`);
    console.log("res:", res.data);
    return res.data;
  } catch (err) {
    console.log(`ERROR: cannot remove shop item ${id}`, err);
    return err;
  }
}

function save(shopItem) {
  return shopItem.shopItemId ? _update(shopItem) : _add(shopItem);
}

async function _update(shopItem) {
  try {
    const res = await axios.post(`${BASE_URL}/update`, shopItem);
    return res.data;
  } catch (err) {
    console.log(`ERROR: cannot update shop item ${shopItem.shopItemId}`, err);
    return err;
  }
}

async function _add(shopItem) {
  try {
    const res = await axios.post(`${BASE_URL}/add`, shopItem);
    console.log("res:", res.data);
    return res.data;
  } catch (err) {
    console.log("ERROR: cannot add shop item", err);
    return err;
  }
}

function getEmptyShopItem() {
  return {
    affiliatorId: " ",
    categories: [],
    createdTs: Date.now(),
    imageUrl: " ",
    lastUpdatedTs: Date.now(),
    link: "",
    shopItem: "",
    subjectsOfInterest: [],
    tags: [],
    text: "",
    title: ""
  };
}
