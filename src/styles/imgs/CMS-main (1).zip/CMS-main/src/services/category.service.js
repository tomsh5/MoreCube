import axios from "axios";

export const categoryService = {
  query,
  getById,
  remove,
  save,
  getEmptyCategory,
  getCategoriesToEdit
};

const BASE_URL = "https://dev3.sexence.com:5025";

async function query() {
  try {
    const categories = await axios.get(`${BASE_URL}/categories`);
    return categories.data;
  } catch (err) {
    console.log("ERROR: cannot find categories", err);
  }
}

async function getById(id) {
  try {
    const category = await axios.get(`${BASE_URL}/category/${id}`);
    return category.data;
  } catch (err) {
    console.log("ERROR: cannot find category", err);
  }
}

async function remove(id) {
  try {
    const res = await axios.get(`${BASE_URL}/delete/${id}`);
    console.log("res:", res.data);
    return res.data;
  } catch (err) {
    console.log(`ERROR: cannot remove category ${id}`, err);
    return err;
  }
}

function save(category) {
  return category.categoryId ? _update(category) : _add(category);
}

async function _update(category) {
  try {
    const res = await axios.post(`${BASE_URL}/update`, category);
    return res.data;
  } catch (err) {
    console.log(`ERROR: cannot update category ${category.categoryId}`, err);
    return err;
  }
}

async function _add(category) {
  try {
    const res = await axios.post(`${BASE_URL}/add`, category);
    console.log("res:", res.data);
    return res.data;
  } catch (err) {
    console.log("ERROR: cannot add category", err);
    return err;
  }
}

function getEmptyCategory() {
  return {
    alias: "",
    categoryName: "",
    createdTs: Date.now(),
    description: "",
    imageUrl: "",
    lastUpdatedTs: Date.now(),
    tags: []
  };
}

function getCategoriesToEdit(categories) {
  const categoriesToEdit = [];
  categories.forEach(category => {
    categoriesToEdit.push({
      id: category.categoryId,
      categoryName: category.categoryName,
      isRelatedToContent: false
    });
  });
  return categoriesToEdit;
}
