import axios from "axios";
import { utilService } from "./util.service";

export const dailyForYouService = {
  query,
  getById,
  remove,
  save,
  getEmptyForYou
};

const BASE_URL = "https://dev3.sexence.com:5028";

async function query() {
  try {
    const forYous = await axios.get(`${BASE_URL}/dailyForYou`);
    return forYous.data;
  } catch (err) {
    console.log("ERROR: cannot find for yous", err);
  }
}

async function getById(id) {
  try {
    const forYou = await axios.get(`${BASE_URL}/dailyForYou/${id}`);
    return forYou.data;
  } catch (err) {
    console.log("ERROR: cannot find for you", err);
  }
}

async function remove(id) {
  try {
    const res = await axios.get(`${BASE_URL}/delete/${id}`);
    console.log("res:", res.data);
    return res.data;
  } catch (err) {
    console.log(`ERROR: cannot remove for you ${id}`, err);
    return err;
  }
}

function save(forYou) {
  return forYou.dailyForYouId ? _update(forYou) : _add(forYou);
}

async function _update(forYou) {
  try {
    const res = await axios.post(`${BASE_URL}/update`, forYou);
    return res.data;
  } catch (err) {
    console.log(`ERROR: cannot update for you ${forYou.forYouId}`, err);
    return err;
  }
}

async function _add(forYou) {
  try {
    const res = await axios.post(`${BASE_URL}/add`, forYou);
    console.log("res:", res.data);
    return res.data;
  } catch (err) {
    console.log("ERROR: cannot add for you", err);
    return err;
  }
}

function getEmptyForYou() {
  return {
    createdTs: Date.now(),
    lastUpdatedTs: Date.now(),
    advisor: [
      {
        advisorId: utilService.makeId(),
        title: null,
        text: null,
        imageUrl: null,
        teaser: null
      }
    ]
  };
}
