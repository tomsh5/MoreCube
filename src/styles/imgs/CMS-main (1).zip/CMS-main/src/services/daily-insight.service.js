import axios from "axios";

export const dailyInsightService = {
  query,
  getById,
  remove,
  save,
  getEmptyInsight
};

const BASE_URL = "https://dev3.sexence.com:5046";

async function query() {
  try {
    const insights = await axios.get(`${BASE_URL}/dailyInsights`);
    return insights.data;
  } catch (err) {
    console.log("ERROR: cannot find insights", err);
  }
}

async function getById(id) {
  try {
    const insight = await axios.get(`${BASE_URL}/dailyInsight/${id}`);
    return insight.data;
  } catch (err) {
    console.log("ERROR: cannot find insight", err);
  }
}

async function remove(id) {
  try {
    const res = await axios.get(`${BASE_URL}/delete/${id}`);
    console.log("res:", res.data);
    return res.data;
  } catch (err) {
    console.log(`ERROR: cannot remove insight ${id}`, err);
    return err;
  }
}

function save(insight) {
  return insight.dailyInsightId ? _update(insight) : _add(insight);
}

async function _update(insight) {
  try {
    const res = await axios.post(`${BASE_URL}/update`, insight);
    return res.data;
  } catch (err) {
    console.log(`ERROR: cannot update insight ${insight.insightId}`, err);
    return err;
  }
}

async function _add(insight) {
  try {
    const res = await axios.post(`${BASE_URL}/add`, insight);
    console.log("res:", res.data);
    return res.data;
  } catch (err) {
    console.log("ERROR: cannot add insight", err);
    return err;
  }
}

function getEmptyInsight() {
  return {
    createdTs: Date.now(),
    lastUpdatedTs: Date.now(),
    text: "",
    imageUrl: "",
    title: ""
  };
}
