export const filterSortService = {
  filterArray,
  sortArray
};

function filterArray(filterBy, array, title = "title") {
  let filteredArray = array;
  if (filterBy.searchStr) {
    filteredArray = array.filter(article => {
      if (article[title]) {
        return article[title]
          .toLowerCase()
          .includes(filterBy.searchStr.toLowerCase());
      }
    });
  }
  if (filterBy.categoryId) {
    filteredArray = filteredArray.filter(item => {
      const isItemRelatedToCategory = item.categories.some(category => {
        return filterBy.categoryId === category.id || !filterBy.categoryId;
      });
      if (isItemRelatedToCategory) return item;
    });
  }
  if (filterBy.isLive !== null) {
    filteredArray = filteredArray.filter(item => {
      return filterBy.isLive === item.isLive;
    });
  }
  return filteredArray;
}

function sortArray(sortBy, array, title = "title") {
  switch (sortBy) {
    case "lastUpdated":
      array.sort((a, b) => {
        return b.lastUpdatedTs - a.lastUpdatedTs;
      });
      break;
    case title:
      array = array.sort((a, b) => {
        if (a[title]) {
          var titleA = a[title].toUpperCase();
        }
        if (b[title]) {
          var titleB = b[title].toUpperCase();
        }
        if (titleA < titleB) return -1;
        if (titleA > titleB) return 1;
        return 0;
      });
      break;
    case "created":
      array.sort((a, b) => {
        return b.createdTs - a.createdTs;
      });
      break;
    case "dailyPlanNum":
      array.sort((a, b) => {
        return b.dailyPlanNum - a.dailyPlanNum;
      });
      break;
  }
}
