import axios from "axios";

export const secretSexenceQuestionService = {
  query,
  getById,
  remove,
  save,
  getEmptySecretQuestion
};

const BASE_URL = "https://dev3.sexence.com:5036";

async function query() {
  try {
    const secrets = await axios.get(`${BASE_URL}/secrets`);
    return secrets.data;
  } catch (err) {
    console.log("ERROR: cannot find secrets", err);
  }
}

async function getById(id) {
  try {
    const secret = await axios.get(`${BASE_URL}/secret/${id}`);
    return secret.data;
  } catch (err) {
    console.log("ERROR: cannot find secret", err);
  }
}

async function remove(id) {
  try {
    const res = await axios.get(`${BASE_URL}/delete/${id}`);
    console.log("res:", res.data);
    return res.data;
  } catch (err) {
    console.log(`ERROR: cannot remove secret ${id}`, err);
    return err;
  }
}

function save(question) {
  return question.secretId ? _update(question) : _add(question);
}

async function _update(question) {
  try {
    const res = await axios.post(`${BASE_URL}/update`, question);
    console.log("res:", res.data);
    return res.data;
  } catch (err) {
    console.log(`ERROR: cannot update secret ${question.secretId}`, err);
    return err;
  }
}

async function _add(question) {
  try {
    const res = await axios.post(`${BASE_URL}/add`, question);
    console.log("res:", res.data);
    return res.data;
  } catch (err) {
    console.log("ERROR: cannot add question", err);
    return err;
  }
}

function getEmptySecretQuestion() {
  return {
    createdTs: Date.now(),
    imageUrl: " ",
    lastUpdatedTs: Date.now(),
    likes: " ",
    question: "",
    // answers: [
    // 	{
    // 		answerId: utilService.makeId(),
    // 		publisher: null,
    // 		text: null,
    // 		teaser: null,
    // 		title: ' ',
    // 		helpfulCounter: 0,
    // 		notHelpfulCounter: 0,
    // 	},
    // ],
    views: " ",
    isLive: false
  };
}
