import axios from "axios";

export const dailySexenceService = {
  query,
  getById,
  remove,
  save,
  getEmptySexence
};

const BASE_URL = "https://dev3.sexence.com:5037";

async function query() {
  try {
    const dailySexences = await axios.get(`${BASE_URL}/dailySexence`);
    return dailySexences.data;
  } catch (err) {
    console.log("ERROR: cannot find daily sexences", err);
  }
}

async function getById(id) {
  try {
    const dailySexence = await axios.get(`${BASE_URL}/dailySexence/${id}`);
    return dailySexence.data;
  } catch (err) {
    console.log("ERROR: cannot find daily sexence", err);
  }
}

async function remove(id) {
  try {
    const res = await axios.get(`${BASE_URL}/delete/${id}`);
    console.log("res:", res.data);
    return res.data;
  } catch (err) {
    console.log(`ERROR: cannot remove daily sexence ${id}`, err);
    return err;
  }
}

function save(dailySexence) {
  return dailySexence.dailySexenceId
    ? _update(dailySexence)
    : _add(dailySexence);
}

async function _update(dailySexence) {
  try {
    const res = await axios.post(`${BASE_URL}/update`, dailySexence);
    return res.data;
  } catch (err) {
    console.log(
      `ERROR: cannot update daily sexence ${dailySexence.dailySexenceId}`,
      err
    );
    return err;
  }
}

async function _add(dailySexence) {
  try {
    const res = await axios.post(`${BASE_URL}/add`, dailySexence);
    console.log("res:", res.data);
    return res.data;
  } catch (err) {
    console.log("ERROR: cannot add daily sexence", err);
    return err;
  }
}

function getEmptySexence() {
  return {
    createdTs: Date.now(),
    dailyFeedbackId: "",
    dailyForYouId: "",
    dailyQuestionId: "",
    dailyTipId: "",
    dailyInsightId: "",
    lastUpdatedTs: Date.now(),
    dailyPlanDayNum: null,
    dailyPlanNum: 1,
    title: ""
  };
}
