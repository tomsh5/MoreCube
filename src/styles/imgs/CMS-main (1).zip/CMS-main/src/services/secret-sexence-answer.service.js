import axios from "axios";

export const secretSexenceAnswerService = {
  query,
  getById,
  getByQuestionId,
  remove,
  removeByQuestionId,
  save,
  getEmptySecretAnswer
};

const BASE_URL = "https://dev3.sexence.com:5063";

async function query() {
  try {
    const secrets = await axios.get(`${BASE_URL}/secretsAnswers`);
    return secrets.data;
  } catch (err) {
    console.log("ERROR: cannot find answers", err);
  }
}

async function getById(id) {
  try {
    const secret = await axios.get(`${BASE_URL}/secretAnswers/${id}`);
    return secret.data;
  } catch (err) {
    console.log("ERROR: cannot find answer", err);
  }
}

async function getByQuestionId(id) {
  try {
    const secret = await axios.get(`${BASE_URL}/secretAnswersBySecretId/${id}`);
    return secret.data;
  } catch (err) {
    console.log("ERROR: cannot find answers", err);
  }
}

async function remove(id) {
  try {
    const res = await axios.get(`${BASE_URL}/delete/${id}`);
    console.log("res:", res.data);
    return res.data;
  } catch (err) {
    console.log(`ERROR: cannot remove answer ${id}`, err);
    return err;
  }
}

async function removeByQuestionId(id) {
  try {
    const res = await axios.get(`${BASE_URL}/deleteBySecretId/${id}`);
    console.log("res:", res.data);
    return res.data;
  } catch (err) {
    console.log(`ERROR: cannot remove answers to secret ${id}`, err);
    return err;
  }
}

function save(answers) {
  answers.forEach(answer => {
    answer.secretsAnswersId ? _update(answer) : _add(answer);
  });
}

async function _update(answer) {
  try {
    const res = await axios.post(`${BASE_URL}/update`, answer);
    console.log("res:", res.data);
    return res.data;
  } catch (err) {
    console.log(`ERROR: cannot update answer ${answer.answerId}`, err);
    return err;
  }
}

async function _add(answer) {
  try {
    const res = await axios.post(`${BASE_URL}/add`, answer);
    console.log("res:", res.data);
    return res.data;
  } catch (err) {
    console.log("ERROR: cannot add answer", err);
    return err;
  }
}

function getEmptySecretAnswer(id) {
  return {
    createdTs: Date.now(),
    lastUpdatedTs: Date.now(),
    secretId: id,
    publisher: null,
    text: null,
    teaser: null,
    helpfulCounter: 0,
    notHelpfulCounter: 0
  };
}
