import axios from "axios";

export const subjectOfInterestService = {
  query,
  getById,
  remove,
  save,
  getEmptySubjectOfInterest,
  getSubjectsOfInterestToEdit
};

const BASE_URL = "https://dev3.sexence.com:5056";

async function query() {
  try {
    const subjectsOfInterest = await axios.get(
      `${BASE_URL}/subjectsOfInterest`
    );
    return subjectsOfInterest.data;
  } catch (err) {
    console.log("ERROR: cannot find subjects of interest", err);
  }
}

async function getById(id) {
  try {
    const subjectOfInterest = await axios.get(
      `${BASE_URL}/subjectOfInterest/${id}`
    );
    return subjectOfInterest.data;
  } catch (err) {
    console.log("ERROR: cannot find subject of interest", err);
  }
}

async function remove(id) {
  try {
    const res = await axios.get(`${BASE_URL}/delete/${id}`);
    console.log("res:", res.data);
    return res.data;
  } catch (err) {
    console.log(`ERROR: cannot remove subject of interest ${id}`, err);
    return err;
  }
}

function save(subjectOfInterest) {
  return subjectOfInterest.subjectOfInterestId
    ? _update(subjectOfInterest)
    : _add(subjectOfInterest);
}

async function _update(subjectOfInterest) {
  try {
    const res = await axios.post(`${BASE_URL}/update`, subjectOfInterest);
    return res.data;
  } catch (err) {
    console.log(
      `ERROR: cannot update subject of interest ${subjectOfInterest.subjectOfInterestId}`,
      err
    );
    return err;
  }
}

async function _add(subjectOfInterest) {
  try {
    const res = await axios.post(`${BASE_URL}/add`, subjectOfInterest);
    console.log("res:", res.data);
    return res.data;
  } catch (err) {
    console.log("ERROR: cannot add subject of interest", err);
    return err;
  }
}

function getEmptySubjectOfInterest() {
  return {
    alias: "",
    subjectOfInterestName: "",
    createdTs: Date.now(),
    description: "",
    imageUrl: "",
    lastUpdatedTs: Date.now(),
    tags: []
  };
}

function getSubjectsOfInterestToEdit(subjectsOfInterest) {
  const subjectsOfInterestToEdit = [];
  subjectsOfInterest.forEach(subjectOfInterest => {
    subjectsOfInterestToEdit.push({
      id: subjectOfInterest.subjectOfInterestId,
      subjectOfInterestName: subjectOfInterest.subjectOfInterestName,
      isRelatedToContent: false
    });
  });
  return subjectsOfInterestToEdit;
}
