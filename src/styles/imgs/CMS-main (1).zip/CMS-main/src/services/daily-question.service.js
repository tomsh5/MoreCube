import axios from "axios";

export const dailyQuestionService = {
  query,
  getById,
  remove,
  save,
  getEmptyQuestion
};

const BASE_URL = "https://dev3.sexence.com:5030";

async function query() {
  try {
    const questions = await axios.get(`${BASE_URL}/dailyQuestions`);
    return questions.data;
  } catch (err) {
    console.log("ERROR: cannot find questions", err);
  }
}

async function getById(id) {
  try {
    const question = await axios.get(`${BASE_URL}/dailyQuestion/${id}`);
    return question.data;
  } catch (err) {
    console.log("ERROR: cannot find question", err);
  }
}

async function remove(id) {
  try {
    const res = await axios.get(`${BASE_URL}/delete/${id}`);
    console.log("res:", res.data);
    return res.data;
  } catch (err) {
    console.log(`ERROR: cannot remove question ${id}`, err);
    return err;
  }
}

function save(question) {
  return question.dailyQuestionId ? _update(question) : _add(question);
}

async function _update(question) {
  try {
    const res = await axios.post(`${BASE_URL}/update`, question);
    return res.data;
  } catch (err) {
    console.log(`ERROR: cannot update question ${question.questionId}`, err);
    return err;
  }
}

async function _add(question) {
  try {
    const res = await axios.post(`${BASE_URL}/add`, question);
    console.log("res:", res.data);
    return res.data;
  } catch (err) {
    console.log("ERROR: cannot add question", err);
    return err;
  }
}

function getEmptyQuestion() {
  return {
    answers: [],
    questions: [],
    imageUrl: null,
    createdTs: Date.now(),
    lastUpdatedTs: Date.now(),
    text: " ",
    title: null
  };
}
