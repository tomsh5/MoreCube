import axios from "axios";

export const dailyTipService = {
  query,
  getById,
  remove,
  save,
  getEmptyTip
};

const BASE_URL = "https://dev3.sexence.com:5029";

async function query() {
  try {
    const tips = await axios.get(`${BASE_URL}/dailyTips`);
    return tips.data;
  } catch (err) {
    console.log("ERROR: cannot find tips", err);
  }
}

async function getById(id) {
  try {
    const tip = await axios.get(`${BASE_URL}/dailyTip/${id}`);
    return tip.data;
  } catch (err) {
    console.log("ERROR: cannot find tip", err);
  }
}

async function remove(id) {
  try {
    const res = await axios.get(`${BASE_URL}/delete/${id}`);
    console.log("res:", res.data);
    return res.data;
  } catch (err) {
    console.log(`ERROR: cannot remove tip ${id}`, err);
    return err;
  }
}

function save(tip) {
  return tip.dailyTipId ? _update(tip) : _add(tip);
}

async function _update(tip) {
  try {
    const res = await axios.post(`${BASE_URL}/update`, tip);
    return res.data;
  } catch (err) {
    console.log(`ERROR: cannot update tip ${tip.tipId}`, err);
    return err;
  }
}

async function _add(tip) {
  try {
    const res = await axios.post(`${BASE_URL}/add`, tip);
    console.log("res:", res.data);
    return res.data;
  } catch (err) {
    console.log("ERROR: cannot add tip", err);
    return err;
  }
}

function getEmptyTip() {
  return {
    createdTs: Date.now(),
    lastUpdatedTs: Date.now(),
    tipType: "",
    shopItemId: "",
    howToId: "",
    text: "",
    articleId: "",
    date: " ",
    subjectTip: ""
  };
}
