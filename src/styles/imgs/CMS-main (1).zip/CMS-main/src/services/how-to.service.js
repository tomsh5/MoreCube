import axios from "axios";
import { utilService } from "./util.service";

export const howToService = {
  query,
  getById,
  remove,
  save,
  getEmptyHowTo
};

const BASE_URL = "https://dev3.sexence.com:5020";

async function query() {
  try {
    const howTos = await axios.get(`${BASE_URL}/howtos`);
    return howTos.data;
  } catch (err) {
    console.log("ERROR: cannot find how tos", err);
  }
}

async function getById(id) {
  try {
    const howTo = await axios.get(`${BASE_URL}/howto/${id}`);
    return howTo.data;
  } catch (err) {
    console.log("ERROR: cannot find how to", err);
  }
}

async function remove(id) {
  try {
    const res = await axios.get(`${BASE_URL}/delete/${id}`);
    console.log("res:", res.data);
    return res.data;
  } catch (err) {
    console.log(`ERROR: cannot remove howto ${id}`, err);
    return err;
  }
}

function save(howTo) {
  return howTo.howToId ? _update(howTo) : _add(howTo);
}

async function _update(howTo) {
  try {
    const res = await axios.post(`${BASE_URL}/update`, howTo);
    return res.data;
  } catch (err) {
    console.log(`ERROR: cannot update how to ${howTo.howToId}`, err);
    return err;
  }
}

async function _add(howTo) {
  try {
    const res = await axios.post(`${BASE_URL}/add`, howTo);
    console.log("res:", res.data);
    return res.data;
  } catch (err) {
    console.log("ERROR: cannot add how to", err);
    return err;
  }
}

function getEmptyHowTo() {
  return {
    authorDesc: "",
    authorName: "",
    categories: [],
    createdTs: Date.now(),
    date: " ",
    imageUrl: " ",
    lastUpdatedTs: Date.now(),
    likes: " ",
    rank: " ",
    ref: " ",
    isLive: false,
    sections: [
      {
        sectionId: utilService.makeId(),
        shopItemId: null,
        textHtml: null,
        title: null
      }
    ],
    subtitle: " ",
    tags: [],
    thumbUrl: " ",
    title: "",
    views: " "
  };
}
