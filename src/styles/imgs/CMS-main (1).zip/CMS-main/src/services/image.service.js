import axios from 'axios';

export const imageService = {
	query,
	uploadImg,
	getImgThumb,
};

const BASE_URL = 'https://devcdn0.sexence.com:5070';

async function query() {
	try {
		const images = await axios.get(`${BASE_URL}/serverImageList`);
		return images.data;
	} catch (err) {
		console.log('ERROR: cannot find images', err);
	}
}

function uploadImg(imagefile, img) {
	const {
		title,
		name,
		description,
		categories,
		subjectsOfInterest,
		tags,
	} = img;
	const formData = new FormData();
	formData.append('file', imagefile.files[0]);

	return axios
		.post(`${BASE_URL}/uploadImagesToCDN`, formData, {
			headers: {
				ContentType: 'multipart/form-data',
				title,
				name,
				description,
				categories,
				subjectsOfInterest,
				tags,
			},
		})
		.then((res) => {
			alert('Image Upload status: ' + res.statusText);
			return res.data.savedFullFilename;
		})
		.catch((err) => {
			console.error(err);
			alert(err);
		});
}

function getImgThumb(imgName) {
	const reg = /(\....)$/;
	imgName = imgName.replace(reg, '-thumb$1');
	return imgName;
}
