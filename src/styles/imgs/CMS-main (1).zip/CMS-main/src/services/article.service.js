import axios from 'axios';
import { utilService } from './util.service';

export const articleService = {
	query,
	getById,
	remove,
	save,
	getEmptyArticle,
};

const BASE_URL = 'https://dev3.sexence.com:5031';

async function query() {
	try {
		const articles = await axios.get(`${BASE_URL}/articles`);
		return articles.data;
	} catch (err) {
		console.log('ERROR: cannot find articles', err);
	}
}

async function getById(id) {
	try {
		const article = await axios.get(`${BASE_URL}/article/${id}`);
		return article.data;
	} catch (err) {
		console.log('ERROR: cannot find article', err);
	}
}

async function remove(id) {
	try {
		const res = await axios.get(`${BASE_URL}/delete/${id}`);
		console.log('res:', res.data);
		return res.data;
	} catch (err) {
		console.log(`ERROR: cannot remove article ${id}`, err);
		return err;
	}
}

function save(article) {
	return article.articleId ? _update(article) : _add(article);
}

async function _update(article) {
	try {
		const res = await axios.post(`${BASE_URL}/update`, article);
		return res.data;
	} catch (err) {
		console.log(`ERROR: cannot update article ${article.articleId}`, err);
		return err;
	}
}

async function _add(article) {
	try {
		const res = await axios.post(`${BASE_URL}/add`, article);
		console.log('res:', res.data);
		return res.data;
	} catch (err) {
		console.log('ERROR: cannot add article', err);
		return err;
	}
}

function getEmptyArticle() {
	return {
		articleType: ' ',
		isLive: false,
		authorDesc: '',
		authorName: '',
		categories: [],
		createdTs: Date.now(),
		date: ' ',
		estimatedReadingTime: '',
		imageUrl: ' ',
		lastUpdatedTs: Date.now(),
		rank: ' ',
		ref: ' ',
		relatedArticles: ' ',
		likes: 0,
		// howToId: '',
		sections: [
			{
				sectionId: utilService.makeId(),
				shopItemId: '',
				textHtml: null,
				title: '',
				quote: null,
			},
		],
		sources: ' ',
		subtitle: ' ',
		tags: [],
		thumbUrl: ' ',
		title: '',
		views: ' ',
	};
}
