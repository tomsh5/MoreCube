export const imgUrlService = {
	getImgUrl,
};

function getImgUrl(imgUrl, imgPrifixUrl) {
	if (!imgUrl) return;
	const reg = /(\....)$/;
	imgUrl = imgUrl.replace(reg, '-thumb$1');
	if (imgUrl.includes('{ImagesCDNURL}/')) {
		imgUrl = imgUrl.replace('{ImagesCDNURL}/', imgPrifixUrl);
	}
	return imgUrl;
}
