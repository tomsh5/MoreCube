import Vue from 'vue';
import VueRouter from 'vue-router';
import Home from '@/views/Home.vue';
import ArticlePage from '@/views/Article/ArticlePage.vue';
import ArticleEdit from '@/views/Article/ArticleEdit.vue';
import HowToPage from '@/views/HowTo/HowToPage.vue';
import HowToEdit from '@/views/HowTo/HowToEdit.vue';
import DailySexencePage from '@/views/DailySexence/DailySexencePage.vue';
import DailySexenceEdit from '@/views/DailySexence/DailySexenceEdit.vue';
import SecretSexencePage from '@/views/SecretSexence/SecretSexencePage.vue';
import SecretSexenceEdit from '@/views/SecretSexence/SecretSexenceEdit.vue';
import DailyTipPage from '@/views/DailyTip/DailyTipPage.vue';
import DailyTipEdit from '@/views/DailyTip/DailyTipEdit.vue';
import DailyFeedbackPage from '@/views/DailyFeedback/DailyFeedbackPage.vue';
import DailyFeedbackEdit from '@/views/DailyFeedback/DailyFeedbackEdit.vue';
import DailyInsightPage from '@/views/DailyInsight/DailyInsightPage.vue';
import DailyInsightEdit from '@/views/DailyInsight/DailyInsightEdit.vue';
import DailyForYouPage from '@/views/DailyForYou/DailyForYouPage.vue';
import DailyForYouEdit from '@/views/DailyForYou/DailyForYouEdit.vue';
import DailyQuestionPage from '@/views/DailyQuestion/DailyQuestionPage.vue';
import DailyQuestionEdit from '@/views/DailyQuestion/DailyQuestionEdit.vue';
import CategoryPage from '@/views/Category/CategoryPage.vue';
import CategoryEdit from '@/views/Category/CategoryEdit.vue';
import SubjectOfInterestPage from '@/views/SubjectOfInterest/SubjectOfInterestPage.vue';
import SubjectOfInterestEdit from '@/views/SubjectOfInterest/SubjectOfInterestEdit.vue';
import ShopItemPage from '@/views/ShopItem/ShopItemPage.vue';
import ShopItemEdit from '@/views/ShopItem/ShopItemEdit.vue';

Vue.use(VueRouter);

const routes = [
	{
		path: '/',
		name: 'Home',
		component: Home,
	},
	{
		path: '/article',
		name: 'Article-Page',
		component: ArticlePage,
	},
	{
		path: '/article/edit/:articleId?',
		name: 'Article-Edit',
		component: ArticleEdit,
	},
	{
		path: '/howTo',
		name: 'How-To-Page',
		component: HowToPage,
	},
	{
		path: '/howTo/edit/:howToId?',
		name: 'How-To-Edit',
		component: HowToEdit,
	},
	{
		path: '/secretSexence',
		name: 'Secret-Sexence-Page',
		component: SecretSexencePage,
	},
	{
		path: '/secretSexence/edit/:secretQuestionId?',
		name: 'Secret-Sexence-Edit',
		component: SecretSexenceEdit,
	},
	{
		path: '/dailySexence',
		name: 'Daily-Sexence-Page',
		component: DailySexencePage,
	},
	{
		path: '/dailySexence/edit/:dailySexenceId?',
		name: 'Daily-Sexence-Edit',
		component: DailySexenceEdit,
	},
	{
		path: '/dailyTip',
		name: 'Daily-Tip-Page',
		component: DailyTipPage,
	},
	{
		path: '/dailyTip/edit/:dailyTipId?',
		name: 'Daily-Tip-Edit',
		component: DailyTipEdit,
	},
	{
		path: '/dailyFeedback',
		name: 'Daily-Feedback-Page',
		component: DailyFeedbackPage,
	},
	{
		path: '/dailyFeedback/edit/:dailyFeedbackId?',
		name: 'Daily-Feedback-Edit',
		component: DailyFeedbackEdit,
	},
	{
		path: '/dailyInsight',
		name: 'Daily-Insight-Page',
		component: DailyInsightPage,
	},
	{
		path: '/dailyInsight/edit/:dailyInsightId?',
		name: 'Daily-Insight-Edit',
		component: DailyInsightEdit,
	},
	{
		path: '/dailyForYou',
		name: 'Daily-For-You-Page',
		component: DailyForYouPage,
	},
	{
		path: '/dailyForYou/edit/:dailyForYouId?',
		name: 'Daily-For-You-Edit',
		component: DailyForYouEdit,
	},
	{
		path: '/dailyQuestion',
		name: 'Daily-Question-Page',
		component: DailyQuestionPage,
	},
	{
		path: '/dailyQuestion/edit/:dailyQuestionId?',
		name: 'Daily-Question-Edit',
		component: DailyQuestionEdit,
	},
	{
		path: '/category',
		name: 'Category-Page',
		component: CategoryPage,
	},
	{
		path: '/category/edit/:categoryId?',
		name: 'Category-Edit',
		component: CategoryEdit,
	},
	{
		path: '/SubjectOfInterest',
		name: 'Subject-Of-Interest-Page',
		component: SubjectOfInterestPage,
	},
	{
		path: '/subjectOfInterest/edit/:subjectOfInterestId?',
		name: 'Subject-Of-Interest-Edit',
		component: SubjectOfInterestEdit,
	},
	{
		path: '/shopItem',
		name: 'Shop-Item-Page',
		component: ShopItemPage,
	},
	{
		path: '/shopItem/edit/:shopItemId?',
		name: 'Shop-Item-Edit',
		component: ShopItemEdit,
	},
];

const router = new VueRouter({
	routes,
});

export default router;
