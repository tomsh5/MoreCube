import Vue from 'vue';
import Vuex from 'vuex';
import { articleStore } from './modules/article.store.js';
import { howToStore } from './modules/how-to.store.js';
import { categoryStore } from './modules/category.store.js';
import { subjectOfInterestStore } from './modules/subject-of-interest.store.js';
import { secretSexenceStore } from './modules/secret-sexence.store.js';
import { dailySexenceStore } from './modules/daily-sexence.store.js';
import { dailyTipStore } from './modules/daily-tip.store.js';
import { dailyFeedbackStore } from './modules/daily-feedback.store.js';
import { dailyInsightStore } from './modules/daily-insight.store.js';
import { dailyForYouStore } from './modules/daily-for-you.store.js';
import { dailyQuestionStore } from './modules/daily-question.store.js';
import { shopItemStore } from './modules/shop-item.store.js';
import { imageStore } from './modules/image.store.js';
import { filterSortStore } from './modules/filter-sort.store.js';

Vue.use(Vuex);

export default new Vuex.Store({
	state: {
		isProduction: process.env.NODE_ENV === 'production',
	},
	getters: {
		isProduction: (state) => state.isProduction,
		imgPrifixUrl: (state) =>
			state.isProduction
				? // ? "ENTER PRODUNCTION URL/"
				  'https://devcdn0.sexence.com/'
				: 'https://devcdn0.sexence.com/',
	},
	mutations: {},
	actions: {},
	modules: {
		articleStore,
		howToStore,
		categoryStore,
		subjectOfInterestStore,
		secretSexenceStore,
		dailySexenceStore,
		dailyTipStore,
		dailyFeedbackStore,
		dailyInsightStore,
		dailyForYouStore,
		dailyQuestionStore,
		shopItemStore,
		imageStore,
		filterSortStore,
	},
});
