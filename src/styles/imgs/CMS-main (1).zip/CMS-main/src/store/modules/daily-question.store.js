import Vue from "vue";
import Vuex from "vuex";
import { dailyQuestionService } from "@/services/daily-question.service.js";

Vue.use(Vuex);

export const dailyQuestionStore = {
  strict: true,
  state: {
    questions: []
  },
  getters: {
    questions: state => state.questions
  },
  mutations: {
    setQuestions(state, { questions }) {
      state.questions = questions;
    },
    removeQuestion(state, { id }) {
      const idx = state.questions.findIndex(question => question._id === id);
      state.questions.splice(idx, 1);
    },
    addQuestion(state, { question }) {
      state.questions.unshift(question);
    },
    updateQuestion(state, { question }) {
      const idx = state.questions.findIndex(
        a => a.questionId === question.questionId
      );
      state.questions.splice(idx, 1, question);
    }
  },
  actions: {
    loadQuestions({ commit }) {
      return dailyQuestionService.query().then(questions => {
        commit({ type: "setQuestions", questions });
        return questions;
      });
    },
    removeQuestion({ commit }, { id }) {
      return dailyQuestionService.remove(id).then(res => {
        alert(res);
        commit({ type: "removeQuestion", id });
      });
    },
    saveQuestion({ commit }, { question }) {
      const type = question.dailyQuestionId ? "updateQuestion" : "addQuestion";
      return dailyQuestionService.save(question).then(res => {
        alert(res);
        commit({ type, question: question });
      });
    }
  }
};
