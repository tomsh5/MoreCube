import Vue from "vue";
import Vuex from "vuex";
import { dailyTipService } from "@/services/daily-tip.service.js";

Vue.use(Vuex);

export const dailyTipStore = {
  strict: true,
  state: {
    tips: []
  },
  getters: {
    tips: state => state.tips
  },
  mutations: {
    setTips(state, { tips }) {
      state.tips = tips;
    },
    removeTip(state, { id }) {
      const idx = state.tips.findIndex(tip => tip._id === id);
      state.tips.splice(idx, 1);
    },
    addTip(state, { tip }) {
      state.tips.unshift(tip);
    },
    updateTip(state, { tip }) {
      const idx = state.tips.findIndex(a => a.tipId === tip.tipId);
      state.tips.splice(idx, 1, tip);
    }
  },
  actions: {
    loadTips({ commit }) {
      return dailyTipService.query().then(tips => {
        commit({ type: "setTips", tips });
        return tips;
      });
    },
    removeTip({ commit }, { id }) {
      return dailyTipService.remove(id).then(res => {
        alert(res);
        commit({ type: "removeTip", id });
      });
    },
    saveTip({ commit }, { tip }) {
      const type = tip.dailyTipId ? "updateTip" : "addTip";
      return dailyTipService.save(tip).then(res => {
        alert(res);
        commit({ type, tip: tip });
      });
    }
  }
};
