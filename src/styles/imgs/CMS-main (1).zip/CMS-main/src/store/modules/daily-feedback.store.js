import Vue from "vue";
import Vuex from "vuex";
import { dailyFeedbackService } from "@/services/daily-feedback.service.js";

Vue.use(Vuex);

export const dailyFeedbackStore = {
  strict: true,
  state: {
    feedbacks: []
  },
  getters: {
    feedbacks: state => state.feedbacks
  },
  mutations: {
    setFeedbacks(state, { feedbacks }) {
      state.feedbacks = feedbacks;
    },
    removeFeedback(state, { id }) {
      const idx = state.feedbacks.findIndex(feedback => feedback._id === id);
      state.feedbacks.splice(idx, 1);
    },
    addFeedback(state, { feedback }) {
      state.feedbacks.unshift(feedback);
    },
    updateFeedback(state, { feedback }) {
      const idx = state.feedbacks.findIndex(
        a => a.feedbackId === feedback.feedbackId
      );
      state.feedbacks.splice(idx, 1, feedback);
    }
  },
  actions: {
    loadFeedbacks({ commit }) {
      return dailyFeedbackService.query().then(feedbacks => {
        commit({ type: "setFeedbacks", feedbacks });
        return feedbacks;
      });
    },
    removeFeedback({ commit }, { id }) {
      return dailyFeedbackService.remove(id).then(res => {
        alert(res);
        commit({ type: "removeFeedback", id });
      });
    },
    saveFeedback({ commit }, { feedback }) {
      const type = feedback.dailyFeedbackId ? "updateFeedback" : "addFeedback";
      return dailyFeedbackService.save(feedback).then(res => {
        alert(res);
        commit({ type, feedback: feedback });
      });
    }
  }
};
