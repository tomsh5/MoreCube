import Vue from "vue";
import Vuex from "vuex";

Vue.use(Vuex);

export const filterSortStore = {
  strict: true,
  state: {
    filterBy: null,
    sortBy: "lastUpdated"
  },
  getters: {
    filterBy: state => state.filterBy,
    sortBy: state => state.sortBy
  },
  mutations: {
    setFilterBy(state, { filterBy }) {
      state.filterBy = filterBy;
    },
    setSortBy(state, { sortBy }) {
      state.sortBy = sortBy;
    }
  },
  actions: {}
};
