import Vue from "vue";
import Vuex from "vuex";
import { dailyForYouService } from "@/services/daily-for-you.service.js";

Vue.use(Vuex);

export const dailyForYouStore = {
  strict: true,
  state: {
    forYous: []
  },
  getters: {
    forYous: state => state.forYous
  },
  mutations: {
    setForYous(state, { forYous }) {
      state.forYous = forYous;
    },
    removeForYou(state, { id }) {
      const idx = state.forYous.findIndex(forYou => forYou._id === id);
      state.forYous.splice(idx, 1);
    },
    addForYou(state, { forYou }) {
      state.forYous.unshift(forYou);
    },
    updateForYou(state, { forYou }) {
      const idx = state.forYous.findIndex(a => a.forYouId === forYou.forYouId);
      state.forYous.splice(idx, 1, forYou);
    }
  },
  actions: {
    loadForYous({ commit }) {
      return dailyForYouService.query().then(forYous => {
        //COMMENT: converting string to array
        forYous.forEach(forYou => {
          forYou.advisor = JSON.parse(forYou.advisor);
        });
        commit({ type: "setForYous", forYous });
        return forYous;
      });
    },
    removeForYou({ commit }, { id }) {
      return dailyForYouService.remove(id).then(res => {
        alert(res);
        commit({ type: "removeForYou", id });
      });
    },
    saveForYou({ commit }, { forYou }) {
      const type = forYou.dailyForYouId ? "updateForYou" : "addForYou";
      return dailyForYouService.save(forYou).then(res => {
        alert(res);
        commit({ type, forYou: forYou });
      });
    }
  }
};
