import Vue from "vue";
import Vuex from "vuex";
import { dailySexenceService } from "@/services/daily-sexence.service.js";

Vue.use(Vuex);

export const dailySexenceStore = {
  strict: true,
  state: {
    dailySexences: []
  },
  getters: {
    dailySexences: state => state.dailySexences
  },
  mutations: {
    setDailySexences(state, { dailySexences }) {
      state.dailySexences = dailySexences;
    },
    removeDailySexence(state, { id }) {
      const idx = state.dailySexences.findIndex(
        dailySexence => dailySexence._id === id
      );
      state.dailySexences.splice(idx, 1);
    },
    addDailySexence(state, { dailySexence }) {
      state.dailySexences.unshift(dailySexence);
    },
    updateDailySexence(state, { dailySexence }) {
      const idx = state.dailySexences.findIndex(
        d => d.dailySexenceId === dailySexence.dailySexenceId
      );
      state.dailySexences.splice(idx, 1, dailySexence);
    }
  },
  actions: {
    loadDailySexences({ commit }) {
      return dailySexenceService.query().then(dailySexences => {
        commit({ type: "setDailySexences", dailySexences });
        return dailySexences;
      });
    },
    removeDailySexence({ commit }, { id }) {
      return dailySexenceService.remove(id).then(res => {
        alert(res);
        commit({ type: "removeDailySexence", id });
      });
    },
    saveDailySexence({ commit }, { dailySexence }) {
      const type = dailySexence.dailySexenceId
        ? "updateDailySexence"
        : "addDailySexence";
      return dailySexenceService.save(dailySexence).then(res => {
        alert(res);
        commit({ type, dailySexence: dailySexence });
      });
    }
  }
};
