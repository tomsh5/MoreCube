import Vue from "vue";
import Vuex from "vuex";
import { shopItemService } from "@/services/shop-item.service.js";

Vue.use(Vuex);

export const shopItemStore = {
  strict: true,
  state: {
    shopItems: []
  },
  getters: {
    shopItems: state => state.shopItems
  },
  mutations: {
    setShopItems(state, { shopItems }) {
      state.shopItems = shopItems;
    },
    removeShopItem(state, { id }) {
      const idx = state.shopItems.findIndex(shopItem => shopItem._id === id);
      state.shopItems.splice(idx, 1);
    },
    addShopItem(state, { shopItem }) {
      state.shopItems.unshift(shopItem);
    },
    updateShopItem(state, { shopItem }) {
      const idx = state.shopItems.findIndex(
        a => a.shopItemId === shopItem.shopItemId
      );
      state.shopItems.splice(idx, 1, shopItem);
    }
  },
  actions: {
    async loadShopItems({ commit }) {
      const shopItems = await shopItemService.query();
      shopItems.map(shopItems => {
        shopItems.categories = JSON.parse(shopItems.categories);
        return shopItems;
      });
      commit({ type: "setShopItems", shopItems });
      return shopItems;
    },
    async removeShopItem({ commit }, { id }) {
      const res = await shopItemService.remove(id);
      alert(res);
      commit({ type: "removeShopItem", id });
    },
    async saveShopItem({ commit }, { shopItem }) {
      const type = shopItem.shopItemId ? "updateShopItem" : "addShopItem";
      const res = await shopItemService.save(shopItem);
      alert(res);
      commit({ type, shopItem: shopItem });
    }
  }
};
