import Vue from "vue";
import Vuex from "vuex";
import { categoryService } from "@/services/category.service.js";

Vue.use(Vuex);

export const categoryStore = {
  strict: true,
  state: {
    categories: []
  },
  getters: {
    categories: state => state.categories
  },
  mutations: {
    setCategories(state, { categories }) {
      state.categories = categories;
    },
    removeCategory(state, { id }) {
      const idx = state.categories.findIndex(category => category._id === id);
      state.categories.splice(idx, 1);
    },
    addCategory(state, { category }) {
      state.categories.unshift(category);
    },
    updateCategory(state, { category }) {
      const idx = state.categories.findIndex(
        c => c.categoryId === category.categoryId
      );
      state.categories.splice(idx, 1, category);
    }
  },
  actions: {
    loadCategories({ commit }) {
      return categoryService.query().then(categories => {
        commit({ type: "setCategories", categories });
        return categories;
      });
    },
    removeCategory({ commit }, { id }) {
      return categoryService.remove(id).then(res => {
        alert(res);
        commit({ type: "removeCategory", id });
      });
    },
    saveCategory({ commit }, { category }) {
      const type = category.categoryId ? "updateCategory" : "addCategory";
      return categoryService.save(category).then(res => {
        alert(res);
        commit({ type, category: category });
      });
    }
  }
};
