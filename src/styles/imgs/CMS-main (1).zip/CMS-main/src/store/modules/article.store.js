import Vue from 'vue';
import Vuex from 'vuex';
import { articleService } from '@/services/article.service.js';

Vue.use(Vuex);

export const articleStore = {
	strict: true,
	state: {
		articles: [],
	},
	getters: {
		articles: (state) => state.articles,
	},
	mutations: {
		setArticles(state, { articles }) {
			state.articles = articles;
		},
		removeArticle(state, { id }) {
			const idx = state.articles.findIndex((article) => article._id === id);
			state.articles.splice(idx, 1);
		},
		addArticle(state, { article }) {
			state.articles.unshift(article);
		},
		updateArticle(state, { article }) {
			const idx = state.articles.findIndex(
				(a) => a.articleId === article.articleId
			);
			state.articles.splice(idx, 1, article);
		},
	},
	actions: {
		async loadArticles({ commit }) {
			const articles = await articleService.query();
			articles.map((article) => {
				article.categories = JSON.parse(article.categories);
				article.isLive = JSON.parse(article.isLive);
				return article;
			});
			commit({ type: 'setArticles', articles });
			return articles;
		},
		async removeArticle({ commit }, { id }) {
			const res = await articleService.remove(id);
			alert(res);
			commit({ type: 'removeArticle', id });
		},
		async saveArticle({ commit }, { article }) {
			const type = article.articleId ? 'updateArticle' : 'addArticle';
			const res = await articleService.save(article);
			alert(res);
			commit({ type, article: article });
		},
	},
};
