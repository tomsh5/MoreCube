import Vue from "vue";
import Vuex from "vuex";
import { imageService } from "@/services/image.service.js";

Vue.use(Vuex);

export const imageStore = {
  strict: true,
  state: {
    images: []
  },
  getters: {
    images: state => state.images
  },
  mutations: {
    setImages(state, { images }) {
      state.images = images;
    }
  },
  actions: {
    loadImages({ commit }) {
      return imageService.query().then(images => {
        commit({ type: "setImages", images });
        return images;
      });
    }
  }
};
