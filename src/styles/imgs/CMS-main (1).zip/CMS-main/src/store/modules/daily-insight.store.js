import Vue from "vue";
import Vuex from "vuex";
import { dailyInsightService } from "@/services/daily-insight.service.js";

Vue.use(Vuex);

export const dailyInsightStore = {
  strict: true,
  state: {
    insights: []
  },
  getters: {
    insights: state => state.insights
  },
  mutations: {
    setInsights(state, { insights }) {
      state.insights = insights;
    },
    removeInsight(state, { id }) {
      const idx = state.insights.findIndex(insight => insight._id === id);
      state.insights.splice(idx, 1);
    },
    addInsight(state, { insight }) {
      state.insights.unshift(insight);
    },
    updateInsight(state, { insight }) {
      const idx = state.insights.findIndex(
        a => a.insightId === insight.insightId
      );
      state.insights.splice(idx, 1, insight);
    }
  },
  actions: {
    loadInsights({ commit }) {
      return dailyInsightService.query().then(insights => {
        commit({ type: "setInsights", insights });
        return insights;
      });
    },
    removeInsight({ commit }, { id }) {
      return dailyInsightService.remove(id).then(res => {
        alert(res);
        commit({ type: "removeInsight", id });
      });
    },
    saveInsight({ commit }, { insight }) {
      const type = insight.dailyInsightId ? "updateInsight" : "addInsight";
      return dailyInsightService.save(insight).then(res => {
        alert(res);
        commit({ type, insight: insight });
      });
    }
  }
};
