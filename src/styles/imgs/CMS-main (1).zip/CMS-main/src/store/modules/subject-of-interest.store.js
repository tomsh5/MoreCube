import Vue from "vue";
import Vuex from "vuex";
import { subjectOfInterestService } from "@/services/subject-of-interest.service.js";

Vue.use(Vuex);

export const subjectOfInterestStore = {
  strict: true,
  state: {
    subjectsOfInterest: []
  },
  getters: {
    subjectsOfInterest: state => state.subjectsOfInterest
  },
  mutations: {
    setSubjectsOfInterest(state, { subjectsOfInterest }) {
      state.subjectsOfInterest = subjectsOfInterest;
    },
    removeSubjectOfInterest(state, { id }) {
      const idx = state.subjectsOfInterest.findIndex(
        subjectOfInterest => subjectOfInterest._id === id
      );
      state.subjectsOfInterest.splice(idx, 1);
    },
    addSubjectOfInterest(state, { subjectOfInterest }) {
      state.subjectsOfInterest.unshift(subjectOfInterest);
    },
    updateSubjectOfInterest(state, { subjectOfInterest }) {
      const idx = state.subjectsOfInterest.findIndex(
        c => c.subjectOfInterestId === subjectOfInterest.subjectOfInterestId
      );
      state.subjectsOfInterest.splice(idx, 1, subjectOfInterest);
    }
  },
  actions: {
    loadSubjectsOfInterest({ commit }) {
      return subjectOfInterestService.query().then(subjectsOfInterest => {
        commit({ type: "setSubjectsOfInterest", subjectsOfInterest });
        return subjectsOfInterest;
      });
    },
    removeSubjectOfInterest({ commit }, { id }) {
      return subjectOfInterestService.remove(id).then(res => {
        alert(res);
        commit({ type: "removeSubjectOfInterest", id });
      });
    },
    saveSubjectOfInterest({ commit }, { subjectOfInterest }) {
      const type = subjectOfInterest.subjectOfInterestId
        ? "updateSubjectOfInterest"
        : "addSubjectOfInterest";
      return subjectOfInterestService.save(subjectOfInterest).then(res => {
        alert(res);
        commit({ type, subjectOfInterest: subjectOfInterest });
      });
    }
  }
};
