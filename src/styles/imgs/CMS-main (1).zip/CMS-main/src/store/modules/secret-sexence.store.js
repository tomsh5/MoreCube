import Vue from "vue";
import Vuex from "vuex";
import { secretSexenceQuestionService } from "@/services/secret-sexence-question.service.js";
import { secretSexenceAnswerService } from "@/services/secret-sexence-answer.service.js";

Vue.use(Vuex);

export const secretSexenceStore = {
  strict: true,
  state: {
    secrets: []
  },
  getters: {
    secrets: state => state.secrets
  },
  mutations: {
    setSecrets(state, { secrets }) {
      state.secrets = secrets;
    },
    removeSecret(state, { id }) {
      const idx = state.secrets.findIndex(secret => secret.question._id === id);
      state.secrets.splice(idx, 1);
    },
    removeAnswer(state, { id }) {
      state.secrets.forEach(secret => {
        if (secret.answers) {
          const idx = secret.answers.findIndex(answer => {
            answer._id === id;
          });
          if (idx !== -1) {
            secret.answers.splice(idx, 1);
          }
        }
      });
    },
    addSecret(state, { secret }) {
      state.secrets.unshift(secret);
    },
    updateSecret(state, { secret }) {
      const idx = state.secrets.findIndex(
        s => s.question.secretId === secret.question.secretId
      );
      state.secrets.splice(idx, 1, secret);
    }
  },
  actions: {
    async loadSecrets({ commit }) {
      const secrets = await secretSexenceQuestionService.query();
      const answers = await secretSexenceAnswerService.query();
      secrets.map(secret => {
        secret.isLive = JSON.parse(secret.isLive);
        secret.answers = answers.forEach(answer => {
          if (answer.secretId === secret.secretId) return answer;
        });
        return secret;
      });
      commit({ type: "setSecrets", secrets });
      return secrets;
    },
    async removeSecret({ commit }, { id }) {
      const resQuestion = await secretSexenceQuestionService.remove(id);
      await secretSexenceAnswerService.removeByQuestionId(id);
      alert(resQuestion);
      commit({ type: "removeSecret", id });
    },
    async removeAnswer({ commit }, { id }) {
      const resAnswers = await secretSexenceAnswerService.remove(id);
      alert(resAnswers);
      commit({ type: "removeAnswer", id });
    },
    async saveSecret({ commit }, { secret }) {
      const type = secret.question.secretId ? "updateSecret" : "addSecret";
      const resQuestion = await secretSexenceQuestionService.save(
        secret.question
      );
      await secretSexenceAnswerService.save(secret.answers);
      alert(resQuestion);
      commit({ type, secret: secret });
    }
  }
};
