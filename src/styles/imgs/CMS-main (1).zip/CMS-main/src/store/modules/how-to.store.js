import Vue from "vue";
import Vuex from "vuex";
import { howToService } from "@/services/how-to.service.js";

Vue.use(Vuex);

export const howToStore = {
  strict: true,
  state: {
    howTos: []
  },
  getters: {
    howTos: state => state.howTos
  },
  mutations: {
    setHowTos(state, { howTos }) {
      state.howTos = howTos;
    },
    removeHowTo(state, { id }) {
      const idx = state.howTos.findIndex(howTo => howTo._id === id);
      state.howTos.splice(idx, 1);
    },
    addHowTo(state, { howTo }) {
      state.howTos.unshift(howTo);
    },
    updateHowTo(state, { howTo }) {
      const idx = state.howTos.findIndex(a => a.howToId === howTo.howToId);
      state.howTos.splice(idx, 1, howTo);
    }
  },
  actions: {
    async loadHowTos({ commit }) {
      const howTos = await howToService.query();
      howTos.map(howTo => {
        howTo.categories = JSON.parse(howTo.categories);
        howTo.isLive = JSON.parse(howTo.isLive);
        return howTo;
      });
      commit({ type: "setHowTos", howTos });
      return howTos;
    },
    async removeHowTo({ commit }, { id }) {
      const res = await howToService.remove(id);
      alert(res);
      commit({ type: "removeHowTo", id });
    },
    async saveHowTo({ commit }, { howTo }) {
      const type = howTo.howToId ? "updateHowTo" : "addHowTo";
      const res = await howToService.save(howTo);
      alert(res);
      commit({ type, howTo: howTo });
    }
  }
};
