<template>
	<section class="subject-of-interest-edit" v-if="subjectOfInterest">
		<h1>
			{{
				subjectOfInterest.subjectOfInterestId
					? "Edit Subject Of Interest"
					: "Add Subject Of Interest"
			}}
		</h1>
		<form @submit.prevent>
			<LabeledInput
				title="Subject Of Interest ID"
				:isDisabled="true"
				:isRequired="false"
				:val="subjectOfInterest.subjectOfInterestId"
				:width="'width-33'"
			/>
			<LabeledInput
				title="Created At"
				:isDisabled="true"
				:isRequired="false"
				:val="new Date(parseInt(subjectOfInterest.createdTs)).toLocaleString()"
				:width="'width-33'"
				@setData="subjectOfInterest.createdTs = $event"
			/>
			<LabeledInput
				title="Last Updated At"
				:isDisabled="true"
				:isRequired="false"
				:val="
					new Date(parseInt(subjectOfInterest.lastUpdatedTs)).toLocaleString()
				"
				:width="'width-33'"
				@setData="subjectOfInterest.lastUpdatedTs = $event"
			/>
			<br />
			<LabeledInput
				title="Subject Of Interest Name"
				:isDisabled="false"
				:isRequired="true"
				:val="subjectOfInterest.subjectOfInterestName"
				:width="'width-50'"
				@setData="subjectOfInterest.subjectOfInterestName = $event"
			/>
			<LabeledInput
				title="Subject Of Interest Description"
				:isDisabled="false"
				:isRequired="false"
				:val="subjectOfInterest.description"
				:width="'width-50'"
				@setData="subjectOfInterest.description = $event"
			/>
			<!-- <LabeledInput
				title="Subject Of Interest Alias"
				:isDisabled="false"
				:isRequired="false"
				:val="subjectOfInterest.alias"
				@setData="subjectOfInterest.alias = $event"
			/> -->
			<ImageInput
				title="Image URL"
				:objUrl="subjectOfInterest.imageUrl"
				@setImg="subjectOfInterest.imageUrl = $event"
			/>
			<ImgUploader @setImg="subjectOfInterest.imageUrl = $event" />
			<br />
			<button class="btn" @click="saveSubjectOfInterest">
				{{
					subjectOfInterest.subjectOfInterestId
						? "Update Subject Of Interest"
						: "Add Subject Of Interest"
				}}
			</button>
			<button
				class="btn"
				v-if="subjectOfInterest.subjectOfInterestId"
				@click.prevent="removeSubjectOfInterest"
			>
				Delete Subject Of Interest
			</button>
		</form>
	</section>
</template>

<script>
import { subjectOfInterestService } from "@/services/subject-of-interest.service.js";
import LabeledInput from "@/components/Helpers/LabeledInput.vue";
import ImageInput from "@/components/Helpers/ImageInput.vue";
import ImgUploader from "@/components/Helpers/ImgUploader";

export default {
	name: "SubjectOfInterest-Edit",
	components: { LabeledInput, ImageInput, ImgUploader },
	data() {
		return {
			subjectOfInterest: null,
		};
	},
	methods: {
		loadSubjectOfInterest() {
			let { subjectOfInterestId } = this.$route.params;
			if (subjectOfInterestId) {
				subjectOfInterestService
					.getById(subjectOfInterestId)
					.then((subjectOfInterest) => {
						this.subjectOfInterest = JSON.parse(
							JSON.stringify(subjectOfInterest)
						);
					});
			} else {
				this.subjectOfInterest = subjectOfInterestService.getEmptySubjectOfInterest();
			}
		},
		saveSubjectOfInterest() {
			if (!this.subjectOfInterest.subjectOfInterestName)
				return alert("Please add SUBJECR OF INTEREST NAME to continue");
			if (!this.subjectOfInterest.alias) this.subjectOfInterest.alias = " ";
			if (!this.subjectOfInterest.description)
				this.subjectOfInterest.description = " ";
			if (!this.subjectOfInterest.imageUrl)
				this.subjectOfInterest.imageUrl = " ";
			this.subjectOfInterest.lastUpdatedTs = Date.now();
			this.$store
				.dispatch({
					type: "saveSubjectOfInterest",
					subjectOfInterest: this.subjectOfInterest,
				})
				.then(() => {
					this.$router.push("/subjectOfInterest");
					this.loadSubjectOfInterest();
				});
		},
		removeSubjectOfInterest() {
			var validation = confirm(
				"Are you sure you want to DELETE this subject of interest?"
			);
			if (validation === true) {
				this.$store
					.dispatch({
						type: "removeSubjectOfInterest",
						id: this.subjectOfInterest.subjectOfInterestId,
					})
					.then(() => {
						this.$router.push("/subjectOfInterest");
						this.loadSubjectOfInterest();
					});
			}
		},
	},
	created() {
		this.$store.dispatch({ type: "loadImages" });
		this.loadSubjectOfInterest();
	},
	watch: {
		"$route.params.subjectOfInterestId"() {
			this.loadSubjectOfInterest();
		},
	},
};
</script>

<style lang="scss" scoped></style>
