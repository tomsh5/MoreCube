<template>
  <div class="subject-of-interest-page">
    <h1>Subjects Of Interest</h1>
    <FilterSort
      v-if="subjectsOfInterest"
      :titleToSortBy="'subjectOfInterestName'"
    ></FilterSort>
    <SubjectOfInterestList
      v-if="subjectsOfInterest"
      :subjectsOfInterest="subjectsOfInterest"
    />
  </div>
</template>

<script>
import SubjectOfInterestList from "@/components/SubjectOfInterest/SubjectOfInterestList.vue";
import FilterSort from "@/components/Helpers/FilterSort.vue";
import { filterSortService } from "@/services/filter-sort.service";

export default {
  name: "Subject-Of-Interest-Page",
  computed: {
    subjectsOfInterest() {
      const filterBy = this.$store.getters.filterBy;
      const sortBy = this.$store.getters.sortBy;
      const subjectsOfInterest = this.$store.getters.subjectsOfInterest;
      if (sortBy)
        filterSortService.sortArray(
          sortBy,
          subjectsOfInterest,
          "subjectOfInterestName"
        );
      return filterBy
        ? filterSortService.filterArray(
            filterBy,
            subjectsOfInterest,
            "subjectOfInterestName"
          )
        : subjectsOfInterest;
    }
  },
  created() {
    this.$store.dispatch({ type: "loadSubjectsOfInterest" });
  },
  components: {
    SubjectOfInterestList,
    FilterSort
  }
};
</script>
<style lang="scss" scoped>
.subject-of-interest-page {
  text-align: center;
}
</style>
