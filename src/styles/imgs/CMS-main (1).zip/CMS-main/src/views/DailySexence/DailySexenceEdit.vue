<template>
  <section class="daily-sexence-edit" v-if="dailySexence">
    <h1>
      {{
        dailySexence.dailySexenceId ? "Edit Daily Sexence" : "Add Daily Sexence"
      }}
    </h1>
    <form @submit.prevent>
      <LabeledInput
        title="Daily Sexence ID"
        :isDisabled="true"
        :isRequired="false"
        :val="dailySexence.dailySexenceId"
        :width="'width-33'"
      />
      <LabeledInput
        title="Created At"
        :isDisabled="true"
        :isRequired="false"
        :val="new Date(parseInt(dailySexence.createdTs)).toLocaleString()"
        :width="'width-33'"
        @setData="dailySexence.createdTs = $event"
      />
      <LabeledInput
        title="Last Updated At"
        :isDisabled="true"
        :isRequired="false"
        :val="new Date(parseInt(dailySexence.lastUpdatedTs)).toLocaleString()"
        :width="'width-33'"
        @setData="dailySexence.lastUpdatedTs = $event"
      />
      <LabeledInput
        title="Title"
        :isDisabled="false"
        :isRequired="true"
        :val="dailySexence.title"
        :width="'width-100'"
        @setData="dailySexence.title = $event"
      />
      <LabeledInput
        title="Related To Plan Number"
        :isDisabled="true"
        :isRequired="false"
        :val="dailySexence.dailyPlanNum"
        :width="'width-50'"
      />
      <LabeledInput
        title="Day"
        :isDisabled="false"
        :isRequired="true"
        :type="'number'"
        :max="30"
        :min="0"
        :val="dailySexence.dailyPlanDayNum"
        :width="'width-50'"
        @setData="dailySexence.dailyPlanDayNum = $event"
      />
      <div class="labeled-field width-100">
        <label>Daily For You:</label>
        <select v-model="dailySexence.dailyForYouId" required>
          <option
            v-for="forYou in sortByTitle(
              this.$store.getters.forYous,
              'advisor',
              'teaser'
            )"
            :key="forYou.dailyForYouId"
            :value="forYou.dailyForYouId"
          >
            <span v-for="advisor in forYou.advisor" :key="advisor.advisorId"
              >{{ advisor.teaser }}
            </span>
            (ID: {{ forYou.dailyForYouId }})
          </option>
        </select>
      </div>
      <div class="labeled-field width-100">
        <label>Daily Insight:</label>
        <select v-model="dailySexence.dailyInsightId" required>
          <option
            v-for="insight in sortByTitle(this.$store.getters.insights)"
            :key="insight.dailyInsightId"
            :value="insight.dailyInsightId"
          >
            {{ insight.title }} (ID: {{ insight.dailyInsightId }})
          </option>
        </select>
      </div>
      <div class="labeled-field width-100">
        <label>Daily Question:</label>
        <select v-model="dailySexence.dailyQuestionId" required>
          <option
            v-for="question in sortByTitle(this.$store.getters.questions)"
            :key="question.dailyQuestionId"
            :value="question.dailyQuestionId"
          >
            {{ question.title }} (ID: {{ question.dailyQuestionId }})
          </option>
        </select>
      </div>
      <div class="labeled-field width-100">
        <label>Daily Feedback:</label>
        <select v-model="dailySexence.dailyFeedbackId" required>
          <option
            v-for="feedback in sortByTitle(this.$store.getters.feedbacks)"
            :key="feedback.dailyFeedbackId"
            :value="feedback.dailyFeedbackId"
          >
            {{ feedback.title }} (ID: {{ feedback.dailyFeedbackId }})
          </option>
        </select>
      </div>
      <div class="labeled-field width-100">
        <label>Daily Tip:</label>
        <select v-model="dailySexence.dailyTipId" required>
          <option
            v-for="tip in sortByTitle(this.$store.getters.tips, 'subjectTip')"
            :key="tip.dailyTipId"
            :value="tip.dailyTipId"
          >
            {{ tip.subjectTip }} (ID: {{ tip.dailyTipId }})
          </option>
        </select>
      </div>

      <br />
      <button class="btn" @click="saveDailySexence">
        {{
          dailySexence.dailySexenceId
            ? "Update Daily Sexence"
            : "Add Daily Sexence"
        }}
      </button>
      <button
        class="btn"
        v-if="dailySexence.dailySexenceId"
        @click.prevent="removeDailySexence"
      >
        Delete Daily Sexence
      </button>
    </form>
  </section>
</template>

<script>
import { dailySexenceService } from "@/services/daily-sexence.service.js";
import LabeledInput from "@/components/Helpers/LabeledInput.vue";

export default {
  name: "Daily-Sexence-Edit",
  components: { LabeledInput },
  data() {
    return {
      dailySexence: null
    };
  },
  methods: {
    sortByTitle(array, field = "title", secondField = null) {
      let sortedArray = JSON.parse(JSON.stringify(array));
      sortedArray.sort((a, b) => {
        var articleA = null;
        var articleB = null;
        if (secondField) {
          articleA = a[field][0][secondField].toUpperCase();
          articleB = b[field][0][secondField].toUpperCase();
        } else {
          articleA = a[field].toUpperCase();
          articleB = b[field].toUpperCase();
        }
        if (articleA < articleB) return -1;
        if (articleA > articleB) return 1;
        return 0;
      });
      return sortedArray;
    },
    loadDailySexence() {
      let { dailySexenceId } = this.$route.params;
      if (dailySexenceId) {
        dailySexenceService.getById(dailySexenceId).then(dailySexence => {
          this.dailySexence = JSON.parse(JSON.stringify(dailySexence));
        });
      } else {
        this.dailySexence = dailySexenceService.getEmptySexence();
      }
    },
    saveDailySexence() {
      if (!this.dailySexence.title)
        return alert("Please add TITLE to continue");
      if (!this.dailySexence.dailyPlanDayNum)
        return alert("Please add PLAN DAY to continue");
      if (!this.dailySexence.dailyFeedbackId)
        return alert("Please add DAILY FEEDBACK to continue");
      if (!this.dailySexence.dailyQuestionId)
        return alert("Please add DAILY QUESTION to continue");
      if (!this.dailySexence.dailyTipId)
        return alert("Please add DAILY TIP to continue");
      if (!this.dailySexence.dailyForYouId)
        return alert("Please add DAILY FOR YOU to continue");
      if (!this.dailySexence.dailyInsightId)
        return alert("Please add DAILY INSIGHT to continue");
      this.dailySexence.lastUpdatedTs = Date.now();
      this.$store
        .dispatch({ type: "saveDailySexence", dailySexence: this.dailySexence })
        .then(() => {
          this.$router.push("/dailySexence");
          this.loadDailySexence();
        });
    },
    removeDailySexence() {
      var validation = confirm(
        "Are you sure you want to DELETE this daily sexence?"
      );
      if (validation === true) {
        this.$store
          .dispatch({
            type: "removeDailySexence",
            id: this.dailySexence.dailySexenceId
          })
          .then(() => {
            this.$router.push("/dailySexence");
            this.loadDailySexence();
          });
      }
    }
  },
  created() {
    this.loadDailySexence();
    this.$store.dispatch({ type: "loadFeedbacks" });
    this.$store.dispatch({ type: "loadInsights" });
    this.$store.dispatch({ type: "loadTips" });
    this.$store.dispatch({ type: "loadForYous" });
    this.$store.dispatch({ type: "loadQuestions" });
  },
  watch: {
    "$route.params.dailySexenceId"() {
      this.loadDailySexence();
    }
  }
};
</script>

<style lang="scss" scoped></style>
