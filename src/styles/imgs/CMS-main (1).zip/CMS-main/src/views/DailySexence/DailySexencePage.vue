<template>
  <div class="daily-sexence-page">
    <h1>Daily sexence</h1>
    <FilterSort
      v-if="dailySexences"
      :titleToSortBy="'title'"
      :displaySortByPlan="true"
    ></FilterSort>
    <DailySexenceList v-if="dailySexences" :dailySexences="dailySexences" />
  </div>
</template>

<script>
import DailySexenceList from "@/components/DailySexence/DailySexenceList.vue";
import FilterSort from "@/components/Helpers/FilterSort.vue";
import { filterSortService } from "@/services/filter-sort.service";

export default {
  name: "Daily-Sexence-Page",
  computed: {
    dailySexences() {
      const dailySexences = this.$store.getters.dailySexences;
      const filterBy = this.$store.getters.filterBy;
      const sortBy = this.$store.getters.sortBy;
      if (sortBy) filterSortService.sortArray(sortBy, dailySexences);
      return filterBy
        ? filterSortService.filterArray(filterBy, dailySexences)
        : dailySexences;
    }
  },
  created() {
    this.$store.dispatch({ type: "loadDailySexences" });
  },
  components: {
    DailySexenceList,
    FilterSort
  }
};
</script>
<style lang="scss" scoped>
.daily-sexence-page {
  text-align: center;
}
</style>
