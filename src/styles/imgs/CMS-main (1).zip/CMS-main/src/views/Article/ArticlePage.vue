<template>
	<div class="article-page">
		<h1>Articles</h1>
		<FilterSort
			v-if="articles"
			:displayIsLive="true"
			:displayCategories="true"
			:titleToSortBy="'title'"
		></FilterSort>
		<ArticleList v-if="articles" :articles="articles" />
	</div>
</template>

<script>
import ArticleList from "@/components/Article/ArticleList.vue";
import FilterSort from "@/components/Helpers/FilterSort.vue";
import { filterSortService } from "@/services/filter-sort.service";

export default {
	name: "Article-Page",
	computed: {
		articles() {
			const filterBy = this.$store.getters.filterBy;
			const sortBy = this.$store.getters.sortBy;
			const articles = this.$store.getters.articles;
			if (sortBy) filterSortService.sortArray(sortBy, articles);
			return filterBy
				? filterSortService.filterArray(filterBy, articles)
				: articles;
		},
	},
	async created() {
		await this.$store.dispatch({ type: "loadArticles" });
		await this.$store.dispatch({ type: "loadCategories" });
	},
	components: {
		ArticleList,
		FilterSort,
	},
};
</script>
<style lang="scss" scoped>
.article-page {
	text-align: center;
}
</style>
