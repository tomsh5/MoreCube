<template>
	<section class="article-edit" v-if="article">
		<h1>{{ article.articleId ? "Edit Article" : "Add Article" }}</h1>
		<IsLiveInput :val="article.isLive" @setIsLive="article.isLive = $event" />
		<form @submit.prevent>
			<LabeledInput
				title="Article ID"
				:isDisabled="true"
				:isRequired="false"
				:val="article.articleId"
				:width="'width-25'"
			/>
			<LabeledInput
				title="Created At"
				:isDisabled="true"
				:isRequired="false"
				:val="new Date(parseInt(article.createdTs)).toLocaleString()"
				:width="'width-25'"
				@setData="article.createdTs = $event"
			/>
			<LabeledInput
				title="Last Updated At"
				:isDisabled="true"
				:isRequired="false"
				:val="new Date(parseInt(article.lastUpdatedTs)).toLocaleString()"
				:width="'width-25'"
				@setData="article.lastUpdatedTs = $event"
			/>
			<LabeledInput
				title="Views"
				:isDisabled="true"
				:isRequired="false"
				:val="article.views"
				:width="'width-25'"
				@setData="article.views = $event"
			/>
			<br />
			<!-- <LabeledInput title="Authors Name" :isDisabled="false" :isRequired="true" :val="article.authorName" @setData="article.authorName = $event"/> -->
			<div class="labeled-field width-50">
				<label>Authors Name:</label>
				<select v-model="article.authorName" required>
					<option value="Dr. Reece Malone">Dr. Reece Malone</option>
					<option value="Maya Magnet">Maya Magnet</option>
					<option value="Mor Erlich">Mor Erlich</option>
					<option value="Oren Weitz">Oren Weitz</option>
					<option value="Prof. Rafi Heruti">Prof. Rafi Heruti</option>
					<option value="Prof. Cobi Reisman">Prof. Cobi Reisman</option>
					<option value="Shelly Varod">Shelly Varod</option>
				</select>
			</div>
			<!-- <LabeledInput title="Authors Description" :isDisabled="false" :isRequired="false" :val="article.authorDesc" @setData="article.authorDesc = $event"/> -->
			<LabeledInput
				title="Estimated Reading Time"
				:isDisabled="false"
				:isRequired="true"
				:val="article.estimatedReadingTime"
				:width="'width-50'"
				@setData="article.estimatedReadingTime = $event"
			/>
			<LabeledInput
				title="Title"
				:isDisabled="false"
				:isRequired="true"
				:val="article.title"
				:width="'width-100'"
				@setData="article.title = $event"
			/>
			<!-- <div class="labeled-field">
                <label>Related How-To:</label>
                <select v-model="article.howToId">
                    <option v-for="howTo in (this.$store.getters.howTos)" :key="howTo.howToId" :value="howTo.howToId">ID: {{howTo.howToId}} {{howTo.title}} </option>
                </select>
            </div> -->
			<br />
			<ImageInput
				title="Image URL"
				:objUrl="article.imageUrl"
				@setImg="[(article.imageUrl = $event), (article.thumbUrl = $event)]"
			/>
			<ImgUploader
				@setImg="[(article.imageUrl = $event), (article.thumbUrl = $event)]"
			/>

			<div class="labeled-box">
				<label>Categories:</label>
				<div v-for="category in this.categories" :key="category.categoryId">
					<input type="checkbox" v-model="category.isRelatedToContent" />
					<span>{{ category.categoryName }}</span>
				</div>
			</div>
			<div class="labeled-box">
				<label>Subjects Of Interest:</label>
				<div
					v-for="subjectOfInterest in this.subjectsOfInterest"
					:key="subjectOfInterest.subjectOfInterestId"
				>
					<input
						type="checkbox"
						v-model="subjectOfInterest.isRelatedToContent"
					/>
					<span>{{ subjectOfInterest.subjectOfInterestName }}</span>
				</div>
			</div>
			<div v-if="this.article.sections.length > 1">
				<button class="btn" @click="saveArticle">
					{{ article.articleId ? "Update Article" : "Add Article" }}
				</button>
				<button
					class="btn"
					v-if="article.articleId"
					@click.prevent="removeArticle"
				>
					Delete Article
				</button>
			</div>
			<div class="labeled-box">
				<label>Sections:</label>
				<div
					v-for="(section, key) in this.article.sections"
					:key="section.sectionId"
				>
					<LabeledInput
						title="Section ID"
						:isDisabled="true"
						:isRequired="false"
						:val="section.sectionId"
						:width="'width-25'"
					/>
					<div class="labeled-field">
						<label>Shop Item:</label>
						<select v-model="section.shopItemId">
							<option
								v-for="shopItem in $store.getters.shopItems"
								:key="shopItem.shopItemId"
								:value="shopItem.shopItemId"
							>
								{{ shopItem.title }} (ID: {{ shopItem.shopItemId }})
							</option>
							<option value=" ">None</option>
						</select>
					</div>
					<LabeledInput
						title="Section Title"
						:isDisabled="false"
						:isRequired="false"
						:val="section.title"
						:width="'width-33'"
						@setData="section.title = $event"
					/>
					<div class="btn" @click="removeSection()">X</div>
					<br />
					<div class="labeled-field textarea">
						<label>Section Quote:</label
						><textarea type="text" v-model="section.quote" />
					</div>
					<vue-editor required v-model="section.textHtml"></vue-editor>
					<div class="btn" @click="addSection(key)">Add section</div>
				</div>
			</div>
			<br />
			<button class="btn" @click="saveArticle">
				{{ article.articleId ? "Update Article" : "Add Article" }}
			</button>
			<button
				class="btn"
				v-if="article.articleId"
				@click.prevent="removeArticle"
			>
				Delete Article
			</button>
		</form>
	</section>
</template>

<script>
import { articleService } from "@/services/article.service.js";
import { categoryService } from "@/services/category.service.js";
import { subjectOfInterestService } from "@/services/subject-of-interest.service.js";
import { utilService } from "@/services/util.service.js";
import { VueEditor } from "vue2-editor";
import IsLiveInput from "@/components/Helpers/IsLiveInput.vue";
import LabeledInput from "@/components/Helpers/LabeledInput.vue";
import ImageInput from "@/components/Helpers/ImageInput.vue";
import ImgUploader from "@/components/Helpers/ImgUploader";

export default {
	name: "Article-Edit",
	components: { VueEditor, IsLiveInput, LabeledInput, ImageInput, ImgUploader },
	data() {
		return {
			article: null,
			categories: null,
			subjectsOfInterest: null,
		};
	},
	methods: {
		loadArticle() {
			const { articleId } = this.$route.params;
			if (articleId) {
				articleService.getById(articleId).then((article) => {
					this.article = JSON.parse(JSON.stringify(article));
					//COMMENT: parsing info from server (arrives as string instead of an array)
					this.article.sections = JSON.parse(this.article.sections);
					this.article.isLive = JSON.parse(this.article.isLive);
					this.article.categories = JSON.parse(this.article.categories);
					this.article.subjectsOfInterest = JSON.parse(
						this.article.subjectsOfInterest
					);
					this.article.tags = JSON.parse(this.article.tags);
					this.article.sources = JSON.parse(this.article.sources);
					//COMMENT: the how to object stores only the category id, so we go through it and update this.categories accordingly.
					this.categories.forEach((category) => {
						this.article.categories.forEach((articleCategory) => {
							if (parseInt(articleCategory.id) === category.id)
								category.isRelatedToContent = true;
						});
					});
					this.subjectsOfInterest.forEach((subjectOfInterest) => {
						this.article.subjectsOfInterest.forEach(
							(articleSubjectOfInterest) => {
								if (
									parseInt(articleSubjectOfInterest.id) === subjectOfInterest.id
								)
									subjectOfInterest.isRelatedToContent = true;
							}
						);
					});
				});
			} else {
				this.article = articleService.getEmptyArticle();
			}
		},
		saveArticle() {
			const areAllSectionsFilled = this.article.sections.every(
				(section) => section.textHtml
			);
			if (!areAllSectionsFilled)
				return alert("Please add content to ALL sections to continue");
			if (!this.article.title) return alert("Please add TITLE to continue");
			if (!this.article.authorName)
				return alert("Please add  AUTHOR NAME to continue");
			if (!this.article.estimatedReadingTime)
				return alert("Please add ESTIMATED READING TIME to continue");
			if (!this.article.authorDesc) this.article.authorDesc = " ";
			if (!this.article.imageUrl) this.article.imageUrl = " ";
			if (!this.article.thumbUrl) this.article.thumbUrl = " ";
			// if (!this.article.howToId) this.article.howToId = ' ';
			if (!this.article.likes) this.article.likes = 0;
			//COMMENT: update the howTo.categories according to server format (only relevent categories ID are stored)
			this.article.categories = [];
			this.categories.forEach((category) => {
				if (category.isRelatedToContent)
					this.article.categories.push({ id: category.id });
			});
			this.article.subjectsOfInterest = [];
			this.subjectsOfInterest.forEach((subjectOfInterest) => {
				if (subjectOfInterest.isRelatedToContent)
					this.article.subjectsOfInterest.push({ id: subjectOfInterest.id });
			});
			this.article.sections.forEach((section) => {
				if (!section.title) section.title = " ";
				if (!section.shopItemId) section.shopItemId = " ";
				if (!section.quote) section.quote = " ";
			});
			this.article.lastUpdatedTs = Date.now();
			this.article.isLive = JSON.stringify(this.article.isLive);
			this.$store
				.dispatch({ type: "saveArticle", article: this.article })
				.then(() => {
					this.$router.push("/article");
					this.loadArticle();
				});
		},
		removeArticle() {
			var validation = confirm("Are you sure you want to DELETE this article?");
			if (validation === true) {
				this.$store
					.dispatch({ type: "removeArticle", id: this.article.articleId })
					.then(() => {
						this.$router.push("/article");
						this.loadArticle();
					});
			}
		},
		addSection(key) {
			let section = {
				sectionId: utilService.makeId(),
				shopItemId: null,
				title: null,
				textHtml: null,
				quote: null,
			};
			this.article.sections.splice(key + 1, 0, section);
		},
		removeSection(id) {
			var validation = confirm("Are you sure you want to DELETE this section?");
			if (validation === true) {
				let idx = this.article.sections.findIndex(
					(section) => section.sectionId === id
				);
				this.article.sections.splice(idx, 1);
			}
		},
	},
	async created() {
		this.$store.dispatch({ type: "loadImages" });
		this.$store.dispatch({ type: "loadHowTos" });
		this.$store.dispatch({ type: "loadShopItems" });
		const categories = await this.$store.dispatch({ type: "loadCategories" });
		this.categories = categoryService.getCategoriesToEdit(categories);
		const subjectsOfInterest = await this.$store.dispatch({
			type: "loadSubjectsOfInterest",
		});
		this.subjectsOfInterest = subjectOfInterestService.getSubjectsOfInterestToEdit(
			subjectsOfInterest
		);
		this.loadArticle();
	},
	watch: {
		"$route.params.articleId"() {
			this.loadArticle();
		},
	},
};
</script>

<style lang="scss" scoped></style>
