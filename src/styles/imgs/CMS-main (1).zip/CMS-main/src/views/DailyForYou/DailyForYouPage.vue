<template>
  <div class="daily-for-you-page">
    <h1>Daily For You</h1>
    <FilterSort v-if="forYous" :titleToSortBy="'title'"></FilterSort>
    <DailyForYouList v-if="forYous" :forYous="forYous" />
  </div>
</template>

<script>
import DailyForYouList from "@/components/DailyForYou/DailyForYouList.vue";
import FilterSort from "@/components/Helpers/FilterSort.vue";
import { filterSortService } from "@/services/filter-sort.service";
export default {
  name: "Daily-For-You-Page",
  computed: {
    forYous() {
      const filterBy = this.$store.getters.filterBy;
      const sortBy = this.$store.getters.sortBy;
      const forYous = this.$store.getters.forYous;
      const modifiedForYous = forYous.map(forYou => {
        forYou.title = forYou.advisor[0].title;
        return forYou;
      });
      if (sortBy) filterSortService.sortArray(sortBy, modifiedForYous);
      return filterBy
        ? filterSortService.filterArray(filterBy, modifiedForYous)
        : forYous;
    }
  },
  created() {
    this.$store.dispatch({ type: "loadForYous" });
  },
  components: {
    DailyForYouList,
    FilterSort
  }
};
</script>
<style lang="scss" scoped>
.daily-for-you-page {
  text-align: center;
}
</style>
