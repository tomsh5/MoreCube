<template>
	<section class="daily-for-you-edit" v-if="forYou">
		<h1>
			{{ forYou.dailyForYouId ? "Edit Daily For You" : "Add Daily For You" }}
		</h1>
		<form @submit.prevent>
			<LabeledInput
				title="Daily For You ID"
				:isDisabled="true"
				:isRequired="false"
				:val="forYou.dailyForYouId"
				:width="'width-33'"
			/>
			<LabeledInput
				title="Created At"
				:isDisabled="true"
				:isRequired="false"
				:val="new Date(parseInt(forYou.createdTs)).toLocaleString()"
				:width="'width-33'"
				@setData="forYou.createdTs = $event"
			/>
			<LabeledInput
				title="Last Updated At"
				:isDisabled="true"
				:isRequired="false"
				:val="new Date(parseInt(forYou.lastUpdatedTs)).toLocaleString()"
				:width="'width-33'"
				@setData="forYou.lastUpdatedTs = $event"
			/>
			<br />
			<div class="labeled-box">
				<label>Advisors:</label>
				<div v-for="advisor in this.forYou.advisor" :key="advisor.title">
					<LabeledInput
						title="Advisor ID"
						:isDisabled="true"
						:isRequired="false"
						:val="advisor.advisorId"
						:width="'width-33'"
					/>
					<LabeledInput
						title="Advisor Teaser"
						:isDisabled="false"
						:isRequired="false"
						:val="advisor.teaser"
						:width="'width-50'"
						@setData="advisor.teaser = $event"
					/>
					<div class="btn" @click="removeAdvisor(advisor.advisorId)">X</div>
					<LabeledInput
						title="Advisor Title"
						:isDisabled="false"
						:isRequired="false"
						:val="advisor.title"
						:width="'width-100'"
						@setData="advisor.title = $event"
					/>
					<br />

					<ImageInput
						title="Image URL"
						:objUrl="advisor.imageUrl"
						@setImg="advisor.imageUrl = $event"
					/>
					<ImgUploader @setImg="advisor.imageUrl = $event" />
					<div class="labeled-field textarea">
						<label>Advisor Text:</label
						><textarea type="text" v-model="advisor.text" />
					</div>
				</div>
				<div class="btn" @click="addAdvisor">Add Advisor</div>
			</div>
			<br />
			<button class="btn" @click="saveForYou">
				{{
					forYou.dailyForYouId ? "Update Daily For You" : "Add Daily For You"
				}}
			</button>
			<button
				class="btn"
				v-if="forYou.dailyForYouId"
				@click.prevent="removeForYou"
			>
				Delete Daily For You
			</button>
		</form>
	</section>
</template>

<script>
import { dailyForYouService } from "@/services/daily-for-you.service.js";
import { utilService } from "@/services/util.service.js";
import LabeledInput from "@/components/Helpers/LabeledInput.vue";
import ImageInput from "@/components/Helpers/ImageInput.vue";
import ImgUploader from "@/components/Helpers/ImgUploader";

export default {
	name: "Daily-For-You-Edit",
	components: { LabeledInput, ImageInput, ImgUploader },
	data() {
		return {
			forYou: null,
		};
	},
	methods: {
		loadForYou() {
			let { dailyForYouId } = this.$route.params;
			if (dailyForYouId) {
				dailyForYouService.getById(dailyForYouId).then((forYou) => {
					this.forYou = JSON.parse(JSON.stringify(forYou));
					this.forYou.advisor = JSON.parse(this.forYou.advisor);
				});
			} else {
				this.forYou = dailyForYouService.getEmptyForYou();
			}
		},
		saveForYou() {
			const areAllAdvisorsFilled = this.forYou.advisor.every(
				(advisor) => advisor.text
			);
			if (!areAllAdvisorsFilled)
				return alert("Please add content to ALL Advisors text to continue");
			if (!this.forYou.subTitle) this.forYou.subTitle = " ";
			this.forYou.lastUpdatedTs = Date.now();
			this.forYou.advisor.forEach((advisor) => {
				if (!advisor.title) advisor.title = " ";
				if (!advisor.imageUrl) advisor.imageUrl = " ";
				if (!advisor.teaser) advisor.teaser = " ";
			});
			this.$store
				.dispatch({ type: "saveForYou", forYou: this.forYou })
				.then(() => {
					this.$router.push("/dailyForYou");
					this.loadForYou();
				});
		},
		removeForYou() {
			var validation = confirm(
				"Are you sure you want to DELETE this daily for you?"
			);
			if (validation === true) {
				this.$store
					.dispatch({ type: "removeForYou", id: this.forYou.dailyForYouId })
					.then(() => {
						this.$router.push("/dailyForYou");
						this.loadForYou();
					});
			}
		},
		addAdvisor() {
			let advisor = {
				advisorId: utilService.makeId(),
				title: null,
				text: null,
				imageUrl: null,
				teaser: null,
			};
			this.forYou.advisor.push(advisor);
		},
		removeAdvisor(id) {
			var validation = confirm("Are you sure you want to DELETE this advisor?");
			if (validation === true) {
				let idx = this.forYou.advisor.findIndex(
					(advisor) => advisor.advisorId === id
				);
				this.forYou.advisor.splice(idx, 1);
			}
		},
	},
	created() {
		this.$store.dispatch({ type: "loadImages" });
		this.loadForYou();
	},
	watch: {
		"$route.params.dailyForYouId"() {
			this.loadForYou();
		},
	},
};
</script>

<style lang="scss" scoped></style>
