<template>
	<section class="secret-sexence-edit" v-if="secret.question">
		<h1>
			{{
				secret.question.secretId ? "Edit Secret Sexence" : "Add Secret Sexence"
			}}
		</h1>
		<IsLiveInput
			:val="secret.question.isLive"
			@setIsLive="secret.question.isLive = $event"
		/>
		<form @submit.prevent>
			<LabeledInput
				title="Secret Sexence ID"
				:isDisabled="true"
				:isRequired="false"
				:val="secret.question.secretId"
				:width="'width-33'"
			/>
			<LabeledInput
				title="Created At"
				:isDisabled="true"
				:isRequired="false"
				:val="new Date(parseInt(secret.question.createdTs)).toLocaleString()"
				:width="'width-33'"
				@setData="secret.question.createdTs = $event"
			/>
			<LabeledInput
				title="Last Updated At"
				:isDisabled="true"
				:isRequired="false"
				:val="
					new Date(parseInt(secret.question.lastUpdatedTs)).toLocaleString()
				"
				:width="'width-33'"
				@setData="secret.question.lastUpdatedTs = $event"
			/>
			<LabeledInput
				title="Views"
				:isDisabled="true"
				:isRequired="false"
				:val="secret.question.views"
				:width="'width-50'"
				@setData="secret.question.views = $event"
			/>
			<LabeledInput
				title="Likes"
				:isDisabled="true"
				:isRequired="false"
				:val="secret.question.likes"
				:width="'width-50'"
				@setData="secret.question.likes = $event"
			/>
			<LabeledInput
				title="Question"
				:isDisabled="false"
				:isRequired="true"
				:val="secret.question.question"
				:width="'width-100'"
				@setData="secret.question.question = $event"
			/>
			<ImageInput
				title="Image URL"
				:objUrl="secret.question.imageUrl"
				@setImg="secret.question.imageUrl = $event"
			/>
			<ImgUploader @setImg="secret.question.imageUrl = $event" />
			<br />

			<div class="labeled-box" v-if="secret.question.secretId">
				<label>Answers:</label>
				<div
					v-for="(answer, key) in this.secret.answers"
					:key="answer.secretsAnswersId"
				>
					<LabeledInput
						title="Answer ID"
						:isDisabled="true"
						:isRequired="true"
						:val="answer.secretsAnswersId"
						:width="'width-33'"
					/>
					<LabeledInput
						title="Helpful Counter"
						:isDisabled="true"
						:isRequired="false"
						:val="answer.helpfulCounter"
					/>
					<LabeledInput
						title="Not Helpful Counter"
						:isDisabled="true"
						:isRequired="false"
						:val="answer.notHelpfulCounter"
					/>
					<div class="btn" @click="removeAnswer(answer.secretsAnswersId, key)">
						X
					</div>
					<LabeledInput
						title="Answer Teaser"
						:isDisabled="false"
						:isRequired="false"
						:val="answer.teaser"
						:width="'width-50'"
						@setData="answer.teaser = $event"
					/>

					<div class="labeled-field width-50">
						<label>Answer Publisher:</label>
						<select v-model="answer.publisher" required>
							<option value="Dr. Reece Malone">Dr. Reece Malone</option>
							<option value="Maya Magnet">Maya Magnet</option>
							<option value="Mor Erlich">Mor Erlich</option>
							<option value="Oren Weitz">Oren Weitz</option>
							<option value="Prof. Rafi Heruti">Prof. Rafi Heruti</option>
							<option value="Prof. Cobi Reisman">Prof. Cobi Reisman</option>
							<option value="Shelly Varod">Shelly Varod</option>
						</select>
					</div>
					<div class="labeled-field textarea width-100">
						<label>Answer Text:</label
						><textarea type="text" v-model="answer.text" />
					</div>
				</div>
				<div class="btn" @click="addAnswer(secret.question.secretId)">
					Add answer
				</div>
			</div>
			<br />
			<button class="btn" @click="saveSecret">
				{{
					secret.question.secretId
						? "Update Secret Sexence"
						: "Add Secret Sexence"
				}}
			</button>
			<button
				class="btn"
				v-if="secret.question.secretId"
				@click.prevent="removeSecret"
			>
				Delete Secret Sexence
			</button>
		</form>
	</section>
</template>

<script>
import { secretSexenceQuestionService } from "@/services/secret-sexence-question.service.js";
import { secretSexenceAnswerService } from "@/services/secret-sexence-answer.service.js";
import IsLiveInput from "@/components/Helpers/IsLiveInput.vue";
import LabeledInput from "@/components/Helpers/LabeledInput.vue";
import ImageInput from "@/components/Helpers/ImageInput.vue";
import ImgUploader from "@/components/Helpers/ImgUploader";

export default {
	name: "Secret-Sexence-Edit",
	components: { IsLiveInput, LabeledInput, ImageInput, ImgUploader },
	data() {
		return {
			secret: {
				question: null,
				answers: [],
			},
		};
	},
	methods: {
		async loadSecret() {
			let { secretQuestionId } = this.$route.params;
			if (secretQuestionId) {
				const secretQuestion = await secretSexenceQuestionService.getById(
					secretQuestionId
				);
				//COMMENT: parsing info from server (arrives as string instead of an array)
				this.secret.question = JSON.parse(JSON.stringify(secretQuestion));
				this.secret.question.isLive = JSON.parse(this.secret.question.isLive);

				const secretAnswers = await secretSexenceAnswerService.getByQuestionId(
					secretQuestionId
				);
				if (secretAnswers) {
					this.secret.answers = JSON.parse(JSON.stringify(secretAnswers));
				}
			} else {
				this.secret.question = secretSexenceQuestionService.getEmptySecretQuestion();
			}
		},
		async saveSecret() {
			if (!this.secret.question.question)
				return alert("Please add QUESTION to continue");

			const areAllAnswersFilled = this.secret.answers.every(
				(answer) => answer.text && answer.teaser
			);
			if (!areAllAnswersFilled)
				return alert("Please add content to ALL Answers to continue");

			if (!this.secret.question.imageUrl) this.secret.question.imageUrl = " ";
			this.secret.question.lastUpdatedTs = Date.now();
			this.secret.question.isLive = JSON.stringify(this.secret.question.isLive);
			this.secret.answers.forEach((answer) => {
				if (!answer.title) answer.title = " ";
				if (!answer.publisher) answer.publisher = " ";
			});
			await this.$store.dispatch({ type: "saveSecret", secret: this.secret });

			this.$router.push("/secretSexence");
			this.loadSecret();
		},
		async removeSecret() {
			var validation = confirm(
				"Are you sure you want to DELETE this secret sexence?"
			);
			if (validation === true) {
				await this.$store.dispatch({
					type: "removeSecret",
					id: this.secret.question.secretId,
				});
				this.$router.push("/secretSexence");
				this.loadSecret();
			}
		},
		addAnswer(questionId) {
			let answer = secretSexenceAnswerService.getEmptySecretAnswer(questionId);
			this.secret.answers.push(answer);
		},
		async removeAnswer(id, key) {
			var validation = confirm("Are you sure you want to DELETE this answer?");
			if (validation === true) {
				this.secret.answers.splice(key, 1);
				if (id) {
					await this.$store.dispatch({
						type: "removeAnswer",
						id,
					});
				}
			}
		},
	},
	created() {
		this.$store.dispatch({ type: "loadImages" });
		this.loadSecret();
	},
	watch: {
		"$route.params.secretId"() {
			this.loadSecret();
		},
	},
};
</script>

<style lang="scss" scoped></style>
