<template>
  <div class="secret-sexence-page">
    <h1>Secret Sexence</h1>
    <FilterSort
      v-if="secrets"
      :displayIsLive="true"
      :titleToSortBy="'question'"
    ></FilterSort>
    <SecretSexenceList v-if="secrets" :secrets="secrets" />
  </div>
</template>

<script>
import SecretSexenceList from "@/components/SecretSexence/SecretSexenceList.vue";
import FilterSort from "@/components/Helpers/FilterSort.vue";
import { filterSortService } from "@/services/filter-sort.service";

export default {
  name: "Secret-Sexence-Page",
  computed: {
    secrets() {
      const filterBy = this.$store.getters.filterBy;
      const sortBy = this.$store.getters.sortBy;
      const secrets = this.$store.getters.secrets;
      if (sortBy) filterSortService.sortArray(sortBy, secrets, "question");
      return filterBy
        ? filterSortService.filterArray(filterBy, secrets, "question")
        : secrets;
    }
  },
  created() {
    this.$store.dispatch({ type: "loadSecrets" });
  },
  components: {
    SecretSexenceList,
    FilterSort
  }
};
</script>
<style lang="scss" scoped>
.secret-sexence-page {
  text-align: center;
}
</style>
