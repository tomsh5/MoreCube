<template>
	<section class="daily-insight-edit" v-if="insight">
		<h1>
			{{ insight.dailyInsightId ? "Edit Daily Insight" : "Add Daily Insight" }}
		</h1>
		<form @submit.prevent>
			<LabeledInput
				title="Daily Insight ID"
				:isDisabled="true"
				:isRequired="false"
				:val="insight.dailyInsightId"
				:width="'width-33'"
			/>
			<LabeledInput
				title="Created At"
				:isDisabled="true"
				:isRequired="false"
				:val="new Date(parseInt(insight.createdTs)).toLocaleString()"
				:width="'width-33'"
				@setData="insight.createdTs = $event"
			/>
			<LabeledInput
				title="Last Updated At"
				:isDisabled="true"
				:isRequired="false"
				:val="new Date(parseInt(insight.lastUpdatedTs)).toLocaleString()"
				:width="'width-33'"
				@setData="insight.lastUpdatedTs = $event"
			/>
			<br />
			<LabeledInput
				title="Title"
				:isDisabled="false"
				:isRequired="true"
				:val="insight.title"
				:width="'width-100'"
				@setData="insight.title = $event"
			/>
			<ImageInput
				title="Image URL"
				:objUrl="insight.imageUrl"
				@setImg="insight.imageUrl = $event"
			/>
			<ImgUploader @setImg="insight.imageUrl = $event" />
			<div class="labeled-field textarea">
				<label>Insight Text:</label
				><textarea type="text" v-model="insight.text" required />
			</div>

			<button class="btn" @click="saveInsight">
				{{
					insight.dailyInsightId ? "Update Daily Insight" : "Add Daily Insight"
				}}
			</button>
			<button
				class="btn"
				v-if="insight.dailyInsightId"
				@click.prevent="removeInsight"
			>
				Delete Daily Insight
			</button>
		</form>
	</section>
</template>

<script>
import { dailyInsightService } from "@/services/daily-insight.service.js";
import LabeledInput from "@/components/Helpers/LabeledInput.vue";
import ImageInput from "@/components/Helpers/ImageInput.vue";
import ImgUploader from "@/components/Helpers/ImgUploader";

export default {
	name: "Daily-Insight-Edit",
	components: { LabeledInput, ImageInput, ImgUploader },
	data() {
		return {
			insight: null,
		};
	},
	methods: {
		loadInsight() {
			let { dailyInsightId } = this.$route.params;
			if (dailyInsightId) {
				dailyInsightService.getById(dailyInsightId).then((insight) => {
					this.insight = JSON.parse(JSON.stringify(insight));
				});
			} else {
				this.insight = dailyInsightService.getEmptyInsight();
			}
		},
		saveInsight() {
			if (!this.insight.title) return alert("Please add TITLE to continue");
			if (!this.insight.text) return alert("Please add TEXT to continue");
			if (!this.insight.imageUrl) this.insight.imageUrl = " ";
			this.insight.lastUpdatedTs = Date.now();
			this.$store
				.dispatch({ type: "saveInsight", insight: this.insight })
				.then(() => {
					this.$router.push("/dailyInsight");
					this.loadInsight();
				});
		},
		removeInsight() {
			var validation = confirm(
				"Are you sure you want to DELETE this daily insight?"
			);
			if (validation === true) {
				this.$store
					.dispatch({ type: "removeInsight", id: this.insight.dailyInsightId })
					.then(() => {
						this.$router.push("/dailyInsight");
						this.loadInsight();
					});
			}
		},
	},
	created() {
		this.$store.dispatch({ type: "loadImages" });
		this.loadInsight();
	},
	watch: {
		"$route.params.dailyInsightId"() {
			this.loadInsight();
		},
	},
};
</script>

<style lang="scss" scoped></style>
