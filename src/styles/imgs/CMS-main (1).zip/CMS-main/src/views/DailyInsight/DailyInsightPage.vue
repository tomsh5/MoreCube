<template>
  <div class="daily-insight-page">
    <h1>Daily Insights</h1>
    <FilterSort v-if="insights" :titleToSortBy="'title'"></FilterSort>
    <DailyInsightList v-if="insights" :insights="insights" />
  </div>
</template>

<script>
import DailyInsightList from "@/components/DailyInsight/DailyInsightList.vue";
import FilterSort from "@/components/Helpers/FilterSort.vue";
import { filterSortService } from "@/services/filter-sort.service";

export default {
  name: "Daily-Insight-Page",
  computed: {
    insights() {
      const filterBy = this.$store.getters.filterBy;
      const sortBy = this.$store.getters.sortBy;
      const insights = this.$store.getters.insights;
      if (sortBy) filterSortService.sortArray(sortBy, insights);
      return filterBy
        ? filterSortService.filterArray(filterBy, insights)
        : insights;
    }
  },
  created() {
    this.$store.dispatch({ type: "loadInsights" });
  },
  components: {
    DailyInsightList,
    FilterSort
  }
};
</script>
<style lang="scss" scoped>
.daily-insight-page {
  text-align: center;
}
</style>
