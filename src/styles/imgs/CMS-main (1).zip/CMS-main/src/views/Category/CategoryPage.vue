<template>
  <div class="category-page">
    <h1>Categories</h1>
    <FilterSort v-if="categories" :titleToSortBy="'categoryName'"></FilterSort>
    <CategoryList v-if="categories" :categories="categories" />
  </div>
</template>

<script>
import CategoryList from "@/components/Category/CategoryList.vue";
import FilterSort from "@/components/Helpers/FilterSort.vue";
import { filterSortService } from "@/services/filter-sort.service";

export default {
  name: "Category-Page",
  computed: {
    categories() {
      const filterBy = this.$store.getters.filterBy;
      const sortBy = this.$store.getters.sortBy;
      const categories = this.$store.getters.categories;
      if (sortBy)
        filterSortService.sortArray(sortBy, categories, "categoryName");
      return filterBy
        ? filterSortService.filterArray(filterBy, categories, "categoryName")
        : categories;
    }
  },
  created() {
    this.$store.dispatch({ type: "loadCategories" });
  },
  components: {
    CategoryList,
    FilterSort
  }
};
</script>
<style lang="scss" scoped>
.category-page {
  text-align: center;
}
</style>
