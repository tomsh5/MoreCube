<template>
	<section class="category-edit" v-if="category">
		<h1>{{ category.categoryId ? "Edit Category" : "Add Category" }}</h1>
		<form @submit.prevent>
			<LabeledInput
				title="Category ID"
				:isDisabled="true"
				:isRequired="false"
				:val="category.categoryId"
				:width="'width-33'"
			/>
			<LabeledInput
				title="Created At"
				:isDisabled="true"
				:isRequired="false"
				:val="new Date(parseInt(category.createdTs)).toLocaleString()"
				:width="'width-33'"
				@setData="category.createdTs = $event"
			/>
			<LabeledInput
				title="Last Updated At"
				:isDisabled="true"
				:isRequired="false"
				:val="new Date(parseInt(category.lastUpdatedTs)).toLocaleString()"
				:width="'width-33'"
				@setData="category.lastUpdatedTs = $event"
			/>
			<br />
			<LabeledInput
				title="Category Name"
				:isDisabled="false"
				:isRequired="true"
				:val="category.categoryName"
				:width="'width-50'"
				@setData="category.categoryName = $event"
			/>
			<!-- <LabeledInput title="Category Description" :isDisabled="false" :isRequired="false" :val="category.description" @setData="category.description = $event"/> -->
			<LabeledInput
				title="Category Alias"
				:isDisabled="false"
				:isRequired="true"
				:val="category.alias"
				:width="'width-50'"
				@setData="category.alias = $event"
			/>
			<ImageInput
				title="Image URL"
				:objUrl="category.imageUrl"
				@setImg="category.imageUrl = $event"
			/>
			<ImgUploader @setImg="category.imageUrl = $event" />
			<br />
			<button class="btn" @click="saveCategory">
				{{ category.categoryId ? "Update Category" : "Add Category" }}
			</button>
			<button
				class="btn"
				v-if="category.categoryId"
				@click.prevent="removeCategory"
			>
				Delete Category
			</button>
		</form>
	</section>
</template>

<script>
import { categoryService } from "@/services/category.service.js";
import LabeledInput from "@/components/Helpers/LabeledInput.vue";
import ImageInput from "@/components/Helpers/ImageInput.vue";
import ImgUploader from "@/components/Helpers/ImgUploader";

export default {
	name: "Category-Edit",
	components: { LabeledInput, ImageInput, ImgUploader },
	data() {
		return {
			category: null,
		};
	},
	methods: {
		loadCategory() {
			let { categoryId } = this.$route.params;
			if (categoryId) {
				categoryService.getById(categoryId).then((category) => {
					this.category = JSON.parse(JSON.stringify(category));
				});
			} else {
				this.category = categoryService.getEmptyCategory();
			}
		},
		saveCategory() {
			if (!this.category.categoryName)
				return alert("Please add CATEGORY NAME to continue");
			if (!this.category.alias)
				return alert("Please add CATEGORY ALIAS to continue");
			if (!this.category.description) this.category.description = " ";
			if (!this.category.imageUrl) this.category.imageUrl = " ";
			this.category.lastUpdatedTs = Date.now();
			this.$store
				.dispatch({ type: "saveCategory", category: this.category })
				.then(() => {
					this.$router.push("/category");
					this.loadCategory();
				});
		},
		removeCategory() {
			var validation = confirm(
				"Are you sure you want to DELETE this daily category?"
			);
			if (validation === true) {
				this.$store
					.dispatch({ type: "removeCategory", id: this.category.categoryId })
					.then(() => {
						this.$router.push("/category");
						this.loadCategory();
					});
			}
		},
	},
	created() {
		this.$store.dispatch({ type: "loadImages" });
		this.loadCategory();
	},
	watch: {
		"$route.params.categoryId"() {
			this.loadCategory();
		},
	},
};
</script>

<style lang="scss" scoped></style>
