<template>
  <div class="how-to-page">
    <h1>How-To's</h1>
    <FilterSort
      v-if="howTos"
      :displayIsLive="true"
      :displayCategories="true"
      :titleToSortBy="'title'"
    ></FilterSort>
    <HowToList v-if="howTos" :howTos="howTos" />
  </div>
</template>

<script>
import HowToList from "@/components/HowTo/HowToList.vue";
import FilterSort from "@/components/Helpers/FilterSort.vue";
import { filterSortService } from "@/services/filter-sort.service";

export default {
  name: "How-To-Page",
  computed: {
    howTos() {
      const filterBy = this.$store.getters.filterBy;
      const sortBy = this.$store.getters.sortBy;
      const howTos = this.$store.getters.howTos;
      if (sortBy) filterSortService.sortArray(sortBy, howTos);
      return filterBy
        ? filterSortService.filterArray(filterBy, howTos)
        : howTos;
    }
  },
  async created() {
    await this.$store.dispatch({ type: "loadHowTos" });
    await this.$store.dispatch({ type: "loadCategories" });
  },
  components: {
    HowToList,
    FilterSort
  }
};
</script>
<style lang="scss" scoped>
.how-to-page {
  text-align: center;
}
</style>
