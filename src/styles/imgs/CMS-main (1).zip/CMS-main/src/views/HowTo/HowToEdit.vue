<template>
	<section class="how-to-edit" v-if="howTo">
		<h1>{{ howTo.howToId ? "Edit How To" : "Add How To" }}</h1>
		<IsLiveInput :val="howTo.isLive" @setIsLive="howTo.isLive = $event" />
		<form @submit.prevent>
			<LabeledInput
				title="How To ID"
				:isDisabled="true"
				:isRequired="false"
				:val="howTo.howToId"
				:width="'width-25'"
			/>
			<LabeledInput
				title="Created At"
				:isDisabled="true"
				:isRequired="false"
				:val="new Date(parseInt(howTo.createdTs)).toLocaleString()"
				:width="'width-25'"
				@setData="howTo.createdTs = $event"
			/>
			<LabeledInput
				title="Last Updated At"
				:isDisabled="true"
				:isRequired="false"
				:val="new Date(parseInt(howTo.lastUpdatedTs)).toLocaleString()"
				:width="'width-25'"
				@setData="howTo.lastUpdatedTs = $event"
			/>
			<LabeledInput
				title="Views"
				:isDisabled="true"
				:isRequired="false"
				:val="howTo.views"
				:width="'width-25'"
				@setData="howTo.views = $event"
			/>
			<LabeledInput
				title="Title"
				:isDisabled="false"
				:isRequired="true"
				:val="howTo.title"
				:width="'width-50'"
				@setData="howTo.title = $event"
			/>
			<!-- <LabeledInput title="Authors Name" :isDisabled="false" :isRequired="true" :val="howTo.authorName" @setData="howTo.authorName = $event"/> -->
			<div class="labeled-field width-50">
				<label>Authors Name:</label>
				<select v-model="howTo.authorName" required>
					<option value="Dr. Reece Malone">Dr. Reece Malone</option>
					<option value="Maya Magnet">Maya Magnet</option>
					<option value="Mor Erlich">Mor Erlich</option>
					<option value="Oren Weitz">Oren Weitz</option>
					<option value="Prof. Rafi Heruti">Prof. Rafi Heruti</option>
					<option value="Prof. Cobi Reisman">Prof. Cobi Reisman</option>
					<option value="Shelly Varod">Shelly Varod</option>
				</select>
			</div>
			<!-- <LabeledInput title="Description" :isDisabled="false" :isRequired="true" :val="howTo.authorDesc" @setData="howTo.authorDesc = $event"/> -->
			<br />
			<!-- <ImageInput
        title="Thumb URL"
        :objUrl="howTo.thumbUrl"
        @setImg="howTo.thumbUrl = $event"
      /> -->
			<ImageInput
				title="Image URL"
				:objUrl="howTo.imageUrl"
				@setImg="[(howTo.imageUrl = $event), (howTo.thumbUrl = $event)]"
			/>
			<ImgUploader
				@setImg="[(howTo.imageUrl = $event), (howTo.thumbUrl = $event)]"
			/>
			<div class="labeled-box">
				<label v-if="categories">Categories:</label>
				<div v-for="category in this.categories" :key="category.categoryId">
					<input type="checkbox" v-model="category.isRelatedToContent" />
					<span>{{ category.categoryName }}</span>
				</div>
			</div>
			<div class="labeled-box">
				<label v-if="subjectsOfInterest">Subjects Of Interest:</label>
				<div
					v-for="subjectOfInterest in this.subjectsOfInterest"
					:key="subjectOfInterest.subjectOfInterestId"
				>
					<input
						type="checkbox"
						v-model="subjectOfInterest.isRelatedToContent"
					/>
					<span>{{ subjectOfInterest.subjectOfInterestName }}</span>
				</div>
			</div>
			<div v-if="howTo.sections.length > 1">
				<button class="btn" @click="saveHowTo">
					{{ howTo.howToId ? "Update How To" : "Add How To" }}
				</button>
				<button class="btn" v-if="howTo.howToId" @click.prevent="removeHowTo">
					Delete How To
				</button>
			</div>
			<div class="labeled-box">
				<label>Sections:</label>
				<div
					v-for="(section, key) in this.howTo.sections"
					:key="section.sectionId"
				>
					<div class="labeled-field">
						<label>Section ID:</label
						><input disabled type="text" v-model="section.sectionId" />
					</div>
					<div class="labeled-field">
						<label>Shop Item:</label>
						<select v-model="section.shopItemId">
							<option
								v-for="shopItem in $store.getters.shopItems"
								:key="shopItem.shopItemId"
								:value="shopItem.shopItemId"
							>
								{{ shopItem.title }} (ID: {{ shopItem.shopItemId }})
							</option>
							<option value=" ">None</option>
						</select>
					</div>
					<div class="labeled-field width-33">
						<label>Section Title:</label
						><input type="text" v-model="section.title" />
					</div>
					<div class="btn" @click="removeSection(section.sectionId)">X</div>
					<vue-editor required v-model="section.textHtml"></vue-editor>
					<div class="btn" @click="addSection(key)">Add section</div>
				</div>
			</div>
			<br />
			<button class="btn" @click="saveHowTo">
				{{ howTo.howToId ? "Update How To" : "Add How To" }}
			</button>
			<button class="btn" v-if="howTo.howToId" @click.prevent="removeHowTo">
				Delete How To
			</button>
		</form>
	</section>
</template>

<script>
import { howToService } from "@/services/how-to.service.js";
import { categoryService } from "@/services/category.service.js";
import { subjectOfInterestService } from "@/services/subject-of-interest.service.js";
import { utilService } from "@/services/util.service.js";
import { VueEditor } from "vue2-editor";
import IsLiveInput from "@/components/Helpers/IsLiveInput.vue";
import LabeledInput from "@/components/Helpers/LabeledInput.vue";
import ImageInput from "@/components/Helpers/ImageInput.vue";
import ImgUploader from "@/components/Helpers/ImgUploader";

export default {
	name: "How-To-Edit",
	components: { VueEditor, IsLiveInput, LabeledInput, ImageInput, ImgUploader },
	data() {
		return {
			howTo: null,
			categories: null,
			subjectsOfInterest: null,
		};
	},
	methods: {
		loadHowTo() {
			let { howToId } = this.$route.params;
			if (howToId) {
				howToService.getById(howToId).then((howTo) => {
					//COMMENT: parsing info from server (arrives as string instead of an array)
					this.howTo = JSON.parse(JSON.stringify(howTo));
					this.howTo.sections = JSON.parse(this.howTo.sections);
					this.howTo.categories = JSON.parse(this.howTo.categories);
					this.howTo.subjectsOfInterest = JSON.parse(
						this.howTo.subjectsOfInterest
					);
					this.howTo.isLive = JSON.parse(this.howTo.isLive);
					this.howTo.tags = JSON.parse(this.howTo.tags);
					//COMMENT: the how to object stores only the category id, so we go through it and update this.categories accordingly.
					this.categories.forEach((category) => {
						this.howTo.categories.forEach((howToCategory) => {
							if (parseInt(howToCategory.id) === category.id)
								category.isRelatedToContent = true;
						});
					});
					this.subjectsOfInterest.forEach((subjectOfInterest) => {
						this.howTo.subjectsOfInterest.forEach((howToSubjectOfInterest) => {
							if (parseInt(howToSubjectOfInterest.id) === subjectOfInterest.id)
								subjectOfInterest.isRelatedToContent = true;
						});
					});
				});
			} else {
				this.howTo = howToService.getEmptyHowTo();
			}
		},
		saveHowTo() {
			const areAllSectionsFilled = this.howTo.sections.every(
				(section) => section.textHtml
			);
			if (!areAllSectionsFilled)
				return alert("Please add content to ALL sections to continue");

			if (!this.howTo.title) return alert("Please add TITLE to continue");
			if (!this.howTo.authorName)
				return alert("Please add  your NAME to continue");
			// if (!this.howTo.authorDesc) return alert('Please add DESCRIPTION to continue');
			if (!this.howTo.authorDesc) this.howTo.authorDesc = " ";
			if (!this.howTo.imageUrl) this.howTo.imageUrl = " ";
			if (!this.howTo.thumbUrl) this.howTo.thumbUrl = " ";
			//COMMENT: update the howTo.categories according to server format (only relevent categories ID are stored)
			this.howTo.categories = [];
			this.categories.forEach((category) => {
				if (category.isRelatedToContent)
					this.howTo.categories.push({ id: category.id });
			});
			this.howTo.subjectsOfInterest = [];
			this.subjectsOfInterest.forEach((subjectOfInterest) => {
				if (subjectOfInterest.isRelatedToContent)
					this.howTo.subjectsOfInterest.push({ id: subjectOfInterest.id });
			});
			this.howTo.sections.forEach((section) => {
				if (!section.title) section.title = " ";
				if (!section.shopItemId) section.shopItemId = " ";
			});
			this.howTo.isLive = JSON.stringify(this.howTo.isLive);
			this.howTo.lastUpdatedTs = Date.now();
			this.$store
				.dispatch({ type: "saveHowTo", howTo: this.howTo })
				.then(() => {
					this.$router.push("/howTo");
					this.loadHowTo();
				});
		},
		removeHowTo() {
			var validation = confirm("Are you sure you want to DELETE this how to?");
			if (validation === true) {
				this.$store
					.dispatch({ type: "removeHowTo", id: this.howTo.howToId })
					.then(() => {
						this.$router.push("/howTo");
						this.loadHowTo();
					});
			}
		},
		addSection(key) {
			let section = {
				sectionId: utilService.makeId(),
				shopItemId: null,
				title: null,
				textHtml: null,
			};
			this.howTo.sections.splice(key + 1, 0, section);
		},
		removeSection(id) {
			var validation = confirm("Are you sure you want to DELETE this section?");
			if (validation === true) {
				let idx = this.howTo.sections.findIndex(
					(section) => section.sectionId === id
				);
				this.howTo.sections.splice(idx, 1);
			}
		},
	},
	async created() {
		this.$store.dispatch({ type: "loadShopItems" });
		this.$store.dispatch({ type: "loadImages" });
		const categories = await this.$store.dispatch({ type: "loadCategories" });
		//COMMENT: takes "dirty" categories from state and creates a new "clean" (only relevent info) local categories array.
		this.categories = categoryService.getCategoriesToEdit(categories);
		const subjectsOfInterest = await this.$store.dispatch({
			type: "loadSubjectsOfInterest",
		});
		//COMMENT: takes "dirty" categories from state and creates a new "clean" (only relevent info) local categories array.
		this.subjectsOfInterest = subjectOfInterestService.getSubjectsOfInterestToEdit(
			subjectsOfInterest
		);
		this.loadHowTo();
	},
	watch: {
		"$route.params.howToId"() {
			this.loadHowTo();
		},
	},
};
</script>

<style lang="scss" scoped></style>
