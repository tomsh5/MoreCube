<template>
  <div class="shop-item-page">
    <h1>Shop Items</h1>
    <FilterSort v-if="shopItems" :titleToSortBy="'title'"></FilterSort>
    <ShopItemList v-if="shopItems" :shopItems="shopItems" />
  </div>
</template>

<script>
import ShopItemList from "@/components/ShopItem/ShopItemList.vue";
import FilterSort from "@/components/Helpers/FilterSort.vue";
import { filterSortService } from "@/services/filter-sort.service";

export default {
  name: "Shop-Item-Page",
  computed: {
    shopItems() {
      const filterBy = this.$store.getters.filterBy;
      const sortBy = this.$store.getters.sortBy;
      const shopItems = this.$store.getters.shopItems;
      if (sortBy) filterSortService.sortArray(sortBy, shopItems);
      return filterBy
        ? filterSortService.filterArray(filterBy, shopItems)
        : shopItems;
    }
  },
  created() {
    this.$store.dispatch({ type: "loadShopItems" });
  },
  components: {
    ShopItemList,
    FilterSort
  }
};
</script>
<style lang="scss" scoped>
.shop-item-page {
  text-align: center;
}
</style>
