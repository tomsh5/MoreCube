<template>
	<section class="shop-item-edit" v-if="shopItem">
		<h1>{{ shopItem.shopItemId ? "Edit Shop Item" : "Add Shop Item" }}</h1>
		<form @submit.prevent>
			<LabeledInput
				title="Shop Item ID"
				:isDisabled="true"
				:isRequired="false"
				:val="shopItem.shopItemId"
				:width="'width-33'"
			/>
			<LabeledInput
				title="Created At"
				:isDisabled="true"
				:isRequired="false"
				:val="new Date(parseInt(shopItem.createdTs)).toLocaleString()"
				:width="'width-33'"
				@setData="question.createdTs = $event"
			/>
			<LabeledInput
				title="Last Updated At"
				:isDisabled="true"
				:isRequired="false"
				:val="new Date(parseInt(shopItem.lastUpdatedTs)).toLocaleString()"
				:width="'width-33'"
				@setData="question.lastUpdatedTs = $event"
			/>
			<br />
			<LabeledInput
				title="Title"
				:isDisabled="false"
				:isRequired="true"
				:val="shopItem.title"
				:width="'width-50'"
				@setData="shopItem.title = $event"
			/>
			<!-- <LabeledInput title="Affiliator ID" :isDisabled="false" :isRequired="true" :val="shopItem.affiliatorId" @setData="shopItem.affiliatorId = $event"/> -->
			<LabeledInput
				title="Link"
				:isDisabled="false"
				:isRequired="false"
				:val="shopItem.link"
				:width="'width-50'"
				@setData="shopItem.link = $event"
			/>
			<!-- <LabeledInput title="Shop Item" :isDisabled="false" :isRequired="false" :val="shopItem.shopItem" @setData="shopItem.shopItem = $event"/> -->
			<ImageInput
				title="Image URL"
				:objUrl="shopItem.imageUrl"
				@setImg="shopItem.imageUrl = $event"
			/>
			<ImgUploader @setImg="shopItem.imageUrl = $event" />
			<div class="labeled-box">
				<label>Categories:</label>
				<div v-for="category in this.categories" :key="category.categoryId">
					<input type="checkbox" v-model="category.isRelatedToContent" />
					<span>{{ category.categoryName }}</span>
				</div>
			</div>
			<div class="labeled-box">
				<label>Subjects Of Interest:</label>
				<div
					v-for="subjectOfInterest in this.subjectsOfInterest"
					:key="subjectOfInterest.subjectOfInterestId"
				>
					<input
						type="checkbox"
						v-model="subjectOfInterest.isRelatedToContent"
					/>
					<span>{{ subjectOfInterest.subjectOfInterestName }}</span>
				</div>
			</div>
			<div class="labeled-field textarea">
				<label>Text:</label><textarea type="text" v-model="shopItem.text" />
			</div>

			<button class="btn" @click="saveShopItem">
				{{ shopItem.shopItemId ? "Update Shop Item" : "Add Shop Item" }}
			</button>
			<button
				class="btn"
				v-if="shopItem.shopItemId"
				@click.prevent="removeShopItem"
			>
				Delete Shop Item
			</button>
		</form>
	</section>
</template>

<script>
import { shopItemService } from "@/services/shop-item.service.js";
import LabeledInput from "@/components/Helpers/LabeledInput.vue";
import ImageInput from "@/components/Helpers/ImageInput.vue";
import { categoryService } from "@/services/category.service.js";
import { subjectOfInterestService } from "@/services/subject-of-interest.service.js";
import ImgUploader from "@/components/Helpers/ImgUploader";

export default {
	name: "Shop-Item-Edit",
	components: { LabeledInput, ImageInput, ImgUploader },
	data() {
		return {
			shopItem: null,
			categories: null,
			subjectsOfInterest: null,
		};
	},
	methods: {
		loadShopItem() {
			let { shopItemId } = this.$route.params;
			if (shopItemId) {
				shopItemService.getById(shopItemId).then((shopItem) => {
					this.shopItem = JSON.parse(JSON.stringify(shopItem));
					this.shopItem.categories = JSON.parse(this.shopItem.categories);
					this.shopItem.subjectsOfInterest = JSON.parse(
						this.shopItem.subjectsOfInterest
					);
					//COMMENT: the how to object stores only the category id, so we go through it and update this.categories accordingly.
					this.categories.forEach((category) => {
						this.shopItem.categories.forEach((shopItemCategory) => {
							if (parseInt(shopItemCategory.id) === category.id)
								category.isRelatedToContent = true;
						});
					});
					this.subjectsOfInterest.forEach((subjectOfInterest) => {
						this.shopItem.subjectsOfInterest.forEach(
							(shopItemSubjectOfInterest) => {
								if (
									parseInt(shopItemSubjectOfInterest.id) ===
									subjectOfInterest.id
								)
									subjectOfInterest.isRelatedToContent = true;
							}
						);
					});
				});
			} else {
				this.shopItem = shopItemService.getEmptyShopItem();
			}
		},
		saveShopItem() {
			if (!this.shopItem.title) return alert("Please add TITLE to continue");
			if (!this.shopItem.text) this.shopItem.text = " ";
			if (!this.shopItem.shopItem) this.shopItem.shopItem = " ";
			if (!this.shopItem.imageUrl) this.shopItem.imageUrl = " ";
			if (!this.shopItem.link) this.shopItem.link = " ";
			if (!this.shopItem.tags) this.shopItem.tags = [];
			if (!this.shopItem.affiliatorId) this.shopItem.affiliatorId = " ";
			this.shopItem.lastUpdatedTs = Date.now();

			this.shopItem.categories = [];
			this.categories.forEach((category) => {
				if (category.isRelatedToContent)
					this.shopItem.categories.push({ id: category.id });
			});
			this.shopItem.subjectsOfInterest = [];
			this.subjectsOfInterest.forEach((subjectOfInterest) => {
				if (subjectOfInterest.isRelatedToContent)
					this.shopItem.subjectsOfInterest.push({ id: subjectOfInterest.id });
			});

			this.$store
				.dispatch({ type: "saveShopItem", shopItem: this.shopItem })
				.then(() => {
					this.$router.push("/shopItem");
					this.loadShopItem();
				});
		},
		removeShopItem() {
			var validation = confirm(
				"Are you sure you want to DELETE this shop item?"
			);
			if (validation === true) {
				this.$store
					.dispatch({ type: "removeShopItem", id: this.shopItem.shopItemId })
					.then(() => {
						this.$router.push("/shopItem");
						this.loadShopItem();
					});
			}
		},
	},
	async created() {
		this.$store.dispatch({ type: "loadImages" });
		const categories = await this.$store.dispatch({ type: "loadCategories" });
		this.categories = categoryService.getCategoriesToEdit(categories);
		const subjectsOfInterest = await this.$store.dispatch({
			type: "loadSubjectsOfInterest",
		});
		this.subjectsOfInterest = subjectOfInterestService.getSubjectsOfInterestToEdit(
			subjectsOfInterest
		);
		this.loadShopItem();
	},
	watch: {
		"$route.params.shopItemId"() {
			this.loadShopItem();
		},
	},
};
</script>

<style lang="scss" scoped></style>
