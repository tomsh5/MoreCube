<template>
  <div class="daily-tip-page">
    <h1>Daily Tips</h1>
    <FilterSort v-if="tips" :titleToSortBy="'subjectTip'"></FilterSort>
    <DailyTipList v-if="tips" :tips="tips" />
  </div>
</template>

<script>
import DailyTipList from "@/components/DailyTip/DailyTipList.vue";
import FilterSort from "@/components/Helpers/FilterSort.vue";
import { filterSortService } from "@/services/filter-sort.service";

export default {
  name: "Daily-Tip-Page",
  computed: {
    tips() {
      const filterBy = this.$store.getters.filterBy;
      const sortBy = this.$store.getters.sortBy;
      const tips = this.$store.getters.tips;
      if (sortBy) filterSortService.sortArray(sortBy, tips, "subjectTip");
      return filterBy
        ? filterSortService.filterArray(filterBy, tips, "subjectTip")
        : tips;
    }
  },
  created() {
    this.$store.dispatch({ type: "loadTips" });
  },
  components: {
    DailyTipList,
    FilterSort
  }
};
</script>
<style lang="scss" scoped>
.daily-tip-page {
  text-align: center;
}
</style>
