<template>
  <section class="daily-tip-edit" v-if="tip">
    <h1>{{ tip.dailyTipId ? "Edit Daily Tip" : "Add Daily Tip" }}</h1>
    <form @submit.prevent>
      <LabeledInput
        title="Daily Tip ID"
        :isDisabled="true"
        :isRequired="false"
        :val="tip.dailyTipId"
        :width="'width-33'"
      />
      <LabeledInput
        title="Created At"
        :isDisabled="true"
        :isRequired="false"
        :val="new Date(parseInt(tip.createdTs)).toLocaleString()"
        :width="'width-33'"
        @setData="tip.createdTs = $event"
      />
      <LabeledInput
        title="Last Updated At"
        :isDisabled="true"
        :isRequired="false"
        :val="new Date(parseInt(tip.lastUpdatedTs)).toLocaleString()"
        :width="'width-33'"
        @setData="tip.lastUpdatedTs = $event"
      />
      <br />
      <LabeledInput
        title="Title (for CMS use only)"
        :isDisabled="false"
        :isRequired="true"
        :val="tip.subjectTip"
        :width="'width-100'"
        @setData="tip.subjectTip = $event"
      />
      <div class="labeled-field width-50">
        <label>Tip Type:</label>
        <select v-model="tip.tipType">
          <option :value="null">None</option>
          <option value="article">Article</option>
          <option value="howto">How To</option>
          <option value="shopItem">Shop Item</option>
        </select>
      </div>

      <div v-if="tip.tipType === 'article'" class="labeled-field width-50">
        <label>Related Article:</label>
        <select v-model="tip.articleId">
          <option
            v-for="article in sortByTitle(this.$store.getters.articles)"
            :key="article.articleId"
            :value="article.articleId"
          >
            {{ article.title }} (ID: {{ article.articleId }})
          </option>
        </select>
      </div>

      <div v-if="tip.tipType === 'shopItem'" class="labeled-field">
        <label>Related Shop Item:</label>
        <select v-model="tip.shopItemId">
          <option
            v-for="shopItem in sortByTitle(this.$store.getters.shopItems)"
            :key="shopItem.shopItemId"
            :value="shopItem.shopItemId"
          >
            {{ shopItem.title }} (ID: {{ shopItem.shopItemId }})
          </option>
        </select>
      </div>

      <div v-if="tip.tipType === 'howto'" class="labeled-field">
        <label>Related How To:</label>
        <select v-model="tip.howToId">
          <option
            v-for="howTo in sortByTitle(this.$store.getters.howTos)"
            :key="howTo.howToId"
            :value="howTo.howToId"
          >
            {{ howTo.title }} (ID: {{ howTo.howToId }})
          </option>
        </select>
      </div>

      <div class="labeled-field textarea">
        <label>Tip Text:</label
        ><textarea type="text" v-model="tip.text" required />
      </div>

      <button class="btn" @click="saveTip">
        {{ tip.dailyTipId ? "Update Daily Tip" : "Add Daily Tip" }}
      </button>
      <button class="btn" v-if="tip.dailyTipId" @click.prevent="removeTip">
        Delete Daily Tip
      </button>
    </form>
  </section>
</template>

<script>
import { dailyTipService } from "@/services/daily-tip.service.js";
import LabeledInput from "@/components/Helpers/LabeledInput.vue";

export default {
  name: "Daily-Tip-Edit",
  components: { LabeledInput },
  data() {
    return {
      tip: null
    };
  },
  methods: {
    sortByTitle(array) {
      let sortedArray = JSON.parse(JSON.stringify(array));
      sortedArray.sort((a, b) => {
        var articleA = a.title.toUpperCase();
        var articleB = b.title.toUpperCase();
        if (articleA < articleB) return -1;
        if (articleA > articleB) return 1;
        return 0;
      });
      return sortedArray;
    },
    loadTip() {
      let { dailyTipId } = this.$route.params;
      if (dailyTipId) {
        dailyTipService.getById(dailyTipId).then(tip => {
          this.tip = JSON.parse(JSON.stringify(tip));
          // this.tip.text = decodeURI(this.tip.text)
        });
      } else {
        this.tip = dailyTipService.getEmptyTip();
      }
    },
    saveTip() {
      if (!this.tip.text) return alert("Please add TIP TEXT to continue");
      // this.tip.text = encodeURI(this.tip.text)
      if (!this.tip.shopItemId) this.tip.shopItemId = " ";
      if (!this.tip.articleId) this.tip.articleId = " ";
      if (!this.tip.howToId) this.tip.howToId = " ";
      if (!this.tip.tipType) this.tip.tipType = " ";
      if (!this.tip.subjectTip) this.tip.subjectTip = " ";

      switch (this.tip.tipType) {
        case "article":
          this.tip.shopItemId = " ";
          this.tip.howToId = " ";
          break;
        case "shopItem":
          this.tip.articleId = " ";
          this.tip.howToId = " ";
          break;
        case "howto":
          this.tip.shopItemId = " ";
          this.tip.articleId = " ";
          break;
      }
      this.tip.lastUpdatedTs = Date.now();
      this.$store.dispatch({ type: "saveTip", tip: this.tip }).then(() => {
        this.$router.push("/dailyTip");
        this.loadTip();
      });
    },
    removeTip() {
      var validation = confirm(
        "Are you sure you want to DELETE this daily tip?"
      );
      if (validation === true) {
        this.$store
          .dispatch({ type: "removeTip", id: this.tip.dailyTipId })
          .then(() => {
            this.$router.push("/dailyTip");
            this.loadTip();
          });
      }
    }
  },
  created() {
    this.loadTip();
    this.$store.dispatch({ type: "loadArticles" });
    this.$store.dispatch({ type: "loadShopItems" });
    this.$store.dispatch({ type: "loadHowTos" });
  },
  watch: {
    "$route.params.dailyTipId"() {
      this.loadTip();
    }
  }
};
</script>

<style lang="scss" scoped></style>
