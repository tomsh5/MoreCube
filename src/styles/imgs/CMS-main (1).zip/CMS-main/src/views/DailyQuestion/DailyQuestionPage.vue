<template>
  <div class="daily-question-page">
    <h1>Daily Questions</h1>
    <FilterSort v-if="questions" :titleToSortBy="'title'"></FilterSort>
    <DailyQuestionList v-if="questions" :questions="questions" />
  </div>
</template>

<script>
import DailyQuestionList from "@/components/DailyQuestion/DailyQuestionList.vue";
import FilterSort from "@/components/Helpers/FilterSort.vue";
import { filterSortService } from "@/services/filter-sort.service";

export default {
  name: "Daily-Question-Page",
  computed: {
    questions() {
      const filterBy = this.$store.getters.filterBy;
      const sortBy = this.$store.getters.sortBy;
      const questions = this.$store.getters.questions;
      if (sortBy) filterSortService.sortArray(sortBy, questions);
      return filterBy
        ? filterSortService.filterArray(filterBy, questions)
        : questions;
    }
  },
  created() {
    this.$store.dispatch({ type: "loadQuestions" });
  },
  components: {
    DailyQuestionList,
    FilterSort
  }
};
</script>
<style lang="scss" scoped>
.daily-question-page {
  text-align: center;
}
</style>
