<template>
  <section class="daily-question-edit" v-if="question">
    <h1>
      {{
        question.dailyQuestionId ? "Edit Daily Question" : "Add Daily Question"
      }}
    </h1>
    <form @submit.prevent>
      <LabeledInput
        title="Daily Question ID"
        :isDisabled="true"
        :isRequired="false"
        :val="question.dailyQuestionId"
        :width="'width-33'"
      />
      <LabeledInput
        title="Created At"
        :isDisabled="true"
        :isRequired="false"
        :val="new Date(parseInt(question.createdTs)).toLocaleString()"
        :width="'width-33'"
        @setData="question.createdTs = $event"
      />
      <LabeledInput
        title="Last Updated At"
        :isDisabled="true"
        :isRequired="false"
        :val="new Date(parseInt(question.lastUpdatedTs)).toLocaleString()"
        :width="'width-33'"
        @setData="question.lastUpdatedTs = $event"
      />
      <LabeledInput
        title="Title"
        :isDisabled="false"
        :isRequired="true"
        :val="question.title"
        :width="'width-100'"
        @setData="question.title = $event"
      />
      <!-- <ImageInput title="Image URL" :objUrl="question.imageUrl" @setImg="question.imageUrl = $event"/> -->
      <br />
      <div class="labeled-box">
        <label>Questions:</label>
        <div
          v-for="question in this.question.questions"
          :key="question.questionId"
        >
          <LabeledInput
            title="Question ID"
            :isDisabled="true"
            :isRequired="false"
            :val="question.questionId"
          />
          <LabeledInput
            title="Question Title"
            :isDisabled="false"
            :isRequired="true"
            :val="question.title"
            @setData="question.title = $event"
          />

          <div class="labeled-field">
            <label>Answer Structure Type:</label>
            <select v-model="question.answerStructureType" required>
              <option value="select">American</option>
              <option value="open">Open</option>
              <option value="boolean">Yes / No</option>
            </select>
          </div>

          <div class="btn" @click="removeQuestionSection(question.questionId)">
            X
          </div>
        </div>

        <div class="btn" @click="addQuestionSection">Add Question</div>
      </div>
      <div class="labeled-box">
        <label>Answers:</label>
        <div v-for="answer in this.question.answers" :key="answer.answerId">
          <LabeledInput
            title="Answer ID"
            :isDisabled="true"
            :isRequired="false"
            :val="answer.answerId"
            :width="'width-33'"
          />
          <div class="labeled-field width-50">
            <label>To Question:</label>
            <select v-model="answer.questionId" required>
              <option
                v-for="question in question.questions"
                :key="question.questionId"
                :value="question.questionId"
              >
                {{ question.title }} (ID: {{ question.questionId }})
              </option>
            </select>
          </div>
          <div class="btn" @click="removeAnswerSection(answer.answerId)">X</div>
          <div class="labeled-field textarea">
            <label>Answer Text:</label
            ><textarea type="text" v-model="answer.answer" required />
          </div>
        </div>
        <div class="btn" @click="addAnswerSection">Add Answer</div>
      </div>
      <br />
      <button class="btn" @click="saveQuestion">
        {{
          question.dailyQuestionId
            ? "Update Daily Question"
            : "Add Daily Question"
        }}
      </button>
      <button
        class="btn"
        v-if="question.dailyQuestionId"
        @click.prevent="removeQuestion"
      >
        Delete Daily Question
      </button>
    </form>
  </section>
</template>

<script>
import { dailyQuestionService } from "@/services/daily-question.service.js";
import { utilService } from "@/services/util.service.js";
import LabeledInput from "@/components/Helpers/LabeledInput.vue";
// import ImageInput from '@/components/Helpers/ImageInput.vue'

export default {
  name: "Daily-Question-Edit",
  components: { LabeledInput },
  // components: {LabeledInput, ImageInput},
  data() {
    return {
      question: null
    };
  },
  methods: {
    loadQuestion() {
      let { dailyQuestionId } = this.$route.params;
      if (dailyQuestionId) {
        dailyQuestionService.getById(dailyQuestionId).then(question => {
          this.question = JSON.parse(JSON.stringify(question));
          this.question.answers = JSON.parse(this.question.answers);
          this.question.questions = JSON.parse(this.question.questions);
        });
      } else {
        this.question = dailyQuestionService.getEmptyQuestion();
      }
    },
    saveQuestion() {
      if (!this.question.title)
        return alert("Please add QUESTION TITLE to continue");
      if (!this.question.imageUrl) this.question.imageUrl = " ";
      if (!this.question.text) this.question.text = " ";
      this.question.lastUpdatedTs = Date.now();

      const areAllQuestionsFilled = this.question.questions.every(
        question => question.title && question.answerStructureType
      );
      if (!areAllQuestionsFilled)
        return alert("Please add content to ALL questions to continue");
      const areAllAnswersFilled = this.question.answers.every(
        answer => answer.answer && answer.questionId
      );
      if (!areAllAnswersFilled)
        return alert("Please add content to ALL answers to continue");

      this.$store
        .dispatch({ type: "saveQuestion", question: this.question })
        .then(() => {
          this.$router.push("/dailyQuestion");
          this.loadQuestion();
        });
    },
    removeQuestion() {
      var validation = confirm(
        "Are you sure you want to DELETE this daily question?"
      );
      if (validation === true) {
        this.$store
          .dispatch({
            type: "removeQuestion",
            id: this.question.dailyQuestionId
          })
          .then(() => {
            this.$router.push("/dailyQuestion");
            this.loadQuestion();
          });
      }
    },
    addQuestionSection() {
      let question = {
        questionId: utilService.makeId(),
        answerStructureType: null,
        title: null
      };
      this.question.questions.push(question);
    },
    removeQuestionSection(id) {
      var validation = confirm(
        "Are you sure you want to DELETE this question?"
      );
      if (validation === true) {
        let idx = this.question.questions.findIndex(
          question => question.questionId === id
        );
        this.question.questions.splice(idx, 1);
      }
    },
    addAnswerSection() {
      let answer = {
        answerId: utilService.makeId(),
        questionId: null,
        answer: null
      };
      this.question.answers.push(answer);
    },
    removeAnswerSection(id) {
      var validation = confirm("Are you sure you want to DELETE this answer?");
      if (validation === true) {
        let idx = this.question.answers.findIndex(
          answer => answer.answerId === id
        );
        this.question.answers.splice(idx, 1);
      }
    }
  },
  created() {
    this.$store.dispatch({ type: "loadImages" });
    this.loadQuestion();
  },
  watch: {
    "$route.params.dailyQuestionId"() {
      this.loadQuestion();
    }
  }
};
</script>

<style lang="scss" scoped></style>
