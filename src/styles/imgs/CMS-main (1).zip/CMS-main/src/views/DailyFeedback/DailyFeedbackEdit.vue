<template>
  <section class="daily-feedback-edit" v-if="feedback">
    <h1>
      {{
        feedback.dailyFeedbackId ? "Edit Daily Feedback" : "Add Daily Feedback"
      }}
    </h1>
    <form @submit.prevent>
      <LabeledInput
        title="Daily Feedback ID"
        :isDisabled="true"
        :isRequired="false"
        :val="feedback.dailyFeedbackId"
      />
      <LabeledInput
        title="Created At"
        :isDisabled="true"
        :isRequired="false"
        :val="new Date(parseInt(feedback.createdTs)).toLocaleString()"
        @setData="feedback.createdTs = $event"
      />
      <LabeledInput
        title="Last Updated At"
        :isDisabled="true"
        :isRequired="false"
        :val="new Date(parseInt(feedback.lastUpdatedTs)).toLocaleString()"
        @setData="feedback.lastUpdatedTs = $event"
      />
      <LabeledInput
        title="Feedback Title"
        :isDisabled="false"
        :isRequired="false"
        :val="feedback.title"
        @setData="feedback.title = $event"
      />

      <div class="labeled-field textarea">
        <label>Feedback Subtitle:</label
        ><textarea type="text" v-model="feedback.subTitle" required />
      </div>

      <button class="btn" @click="saveFeedback">
        {{
          feedback.dailyFeedbackId
            ? "Update Daily Feedback"
            : "Add Daily Feedback"
        }}
      </button>
      <button
        class="btn"
        v-if="feedback.dailyFeedbackId"
        @click.prevent="removeFeedback"
      >
        Delete Daily Feedback
      </button>
    </form>
  </section>
</template>

<script>
import { dailyFeedbackService } from "@/services/daily-feedback.service.js";
import LabeledInput from "@/components/Helpers/LabeledInput.vue";

export default {
  name: "Daily-Feedback-Edit",
  components: { LabeledInput },
  data() {
    return {
      feedback: null
    };
  },
  methods: {
    loadFeedback() {
      let { dailyFeedbackId } = this.$route.params;
      if (dailyFeedbackId) {
        dailyFeedbackService.getById(dailyFeedbackId).then(feedback => {
          this.feedback = JSON.parse(JSON.stringify(feedback));
        });
      } else {
        this.feedback = dailyFeedbackService.getEmptyFeedback();
      }
    },
    saveFeedback() {
      if (!this.feedback.title) return alert("Please add TITLE to continue");
      if (!this.feedback.subTitle) this.feedback.subTitle = " ";
      this.feedback.lastUpdatedTs = Date.now();
      this.$store
        .dispatch({ type: "saveFeedback", feedback: this.feedback })
        .then(() => {
          this.$router.push("/dailyFeedback");
          this.loadFeedback();
        });
    },
    removeFeedback() {
      var validation = confirm(
        "Are you sure you want to DELETE this daily feedback?"
      );
      if (validation === true) {
        this.$store
          .dispatch({
            type: "removeFeedback",
            id: this.feedback.dailyFeedbackId
          })
          .then(() => {
            this.$router.push("/dailyFeedback");
            this.loadFeedback();
          });
      }
    }
  },
  created() {
    this.loadFeedback();
  },
  watch: {
    "$route.params.dailyFeedbackId"() {
      this.loadFeedback();
    }
  }
};
</script>

<style lang="scss" scoped></style>
