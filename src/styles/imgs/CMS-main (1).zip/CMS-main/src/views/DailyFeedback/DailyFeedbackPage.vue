<template>
  <div class="daily-feedback-page">
    <h1>Daily Feedbacks</h1>
    <FilterSort v-if="feedbacks" :titleToSortBy="'title'"></FilterSort>
    <DailyFeedbackList v-if="feedbacks" :feedbacks="feedbacks" />
  </div>
</template>

<script>
import DailyFeedbackList from "@/components/DailyFeedback/DailyFeedbackList.vue";
import FilterSort from "@/components/Helpers/FilterSort.vue";
import { filterSortService } from "@/services/filter-sort.service";

export default {
  name: "Daily-Feedback-Page",
  computed: {
    feedbacks() {
      const filterBy = this.$store.getters.filterBy;
      const sortBy = this.$store.getters.sortBy;
      const feedbacks = this.$store.getters.feedbacks;
      if (sortBy) filterSortService.sortArray(sortBy, feedbacks);
      return filterBy
        ? filterSortService.filterArray(filterBy, feedbacks)
        : feedbacks;
    }
  },
  created() {
    this.$store.dispatch({ type: "loadFeedbacks" });
  },
  components: {
    DailyFeedbackList,
    FilterSort
  }
};
</script>
<style lang="scss" scoped>
.daily-feedback-page {
  text-align: center;
}
</style>
