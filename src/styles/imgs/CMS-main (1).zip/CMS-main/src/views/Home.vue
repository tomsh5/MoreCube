<template>
  <div class="home">
    <img class="logo" src="@/assets/img/Logo-red.png" alt="SEXENCE" />
    <h1>CMS.</h1>
  </div>
</template>

<script>
export default {
  name: "Home"
};
</script>
