<template>
	<div id="app">
		<div id="nav">
			<router-link to="/">Home</router-link>
			<router-link to="/article">Articles</router-link>
			<router-link to="/howTo">How To</router-link>
			<router-link to="/secretSexence">Secret Sexence</router-link>
			<router-link to="/shopItem">Shop Items</router-link>
			<router-link to="/category">Categories</router-link>
			<router-link to="/subjectOfInterest">Subjects Of Interest</router-link>
			<!-- <br /> -->
			<router-link to="/dailySexence">Daily Sexence</router-link>
			<router-link to="/dailyTip">Daily Tips</router-link>
			<router-link to="/dailyFeedback">Daily Feedbacks</router-link>
			<router-link to="/dailyInsight">Daily Insight</router-link>
			<router-link to="/dailyForYou">Daily For You</router-link>
			<router-link to="/dailyQuestion">Daily Questions</router-link>
		</div>
		<router-view />
	</div>
</template>

<style lang="scss" scoped>
#app {
	#nav {
		display: flex;
		flex-wrap: wrap;
		justify-content: center;
		a {
			color: black;
			font-size: 1.3rem;
			font-weight: 500;
			margin-right: 20px;
			line-height: 2rem;
		}
	}
}
</style>
