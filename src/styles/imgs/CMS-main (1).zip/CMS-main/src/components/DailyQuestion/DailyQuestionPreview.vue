<template>
  <li class="daily-question-preview card">
    <router-link
      :to="'/dailyQuestion/edit/' + question.dailyQuestionId"
      class="flex column space-between"
    >
      <img />
      <h4>{{ question.title }}</h4>
      <p>{{ question.authorName }}</p>
      <p class="card-footer">
        Last Updated: <br />
        {{ new Date(parseInt(question.lastUpdatedTs)).toLocaleString() }}
      </p>
    </router-link>
  </li>
</template>

<script>
export default {
  props: {
    question: {
      type: Object,
      required: true
    }
  }
};
</script>

<style scoped></style>
