<template>
  <section class="daily-question-list">
    <router-link to="/dailyQuestion/edit"
      ><button class="btn">Add New Daily Question</button></router-link
    >
    <ul class="flex wrap justify-center">
      <DailyQuestionPreview
        v-for="question in questions"
        :key="question.questionId"
        :question="question"
      />
    </ul>
  </section>
</template>

<script>
import DailyQuestionPreview from "@/components/DailyQuestion/DailyQuestionPreview";
export default {
  name: "Daily-Question-List",
  props: {
    questions: {
      type: Array,
      required: true
    }
  },
  components: {
    DailyQuestionPreview
  }
};
</script>

<style></style>
