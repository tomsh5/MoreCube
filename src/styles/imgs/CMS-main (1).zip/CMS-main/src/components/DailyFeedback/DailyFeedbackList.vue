<template>
  <section class="daily-feedback-list">
    <router-link to="/dailyFeedback/edit"
      ><button class="btn">Add New Daily Feedback</button></router-link
    >
    <ul class="flex wrap justify-center">
      <DailyFeedbackPreview
        v-for="feedback in feedbacks"
        :key="feedback.feedbackId"
        :feedback="feedback"
      />
    </ul>
  </section>
</template>

<script>
import DailyFeedbackPreview from "@/components/DailyFeedback/DailyFeedbackPreview";
export default {
  name: "Daily-Feedback-List",
  props: {
    feedbacks: {
      type: Array,
      required: true
    }
  },
  data() {
    return {};
  },
  components: {
    DailyFeedbackPreview
  }
};
</script>

<style></style>
