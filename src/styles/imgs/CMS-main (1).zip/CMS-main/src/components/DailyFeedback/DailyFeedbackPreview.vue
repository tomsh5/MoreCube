<template>
  <li class="daily-feedback-preview card">
    <router-link
      :to="'/dailyFeedback/edit/' + feedback.dailyFeedbackId"
      class="flex column space-between"
    >
      <img :src="feedback.thumbUrl" />
      <h4>{{ feedback.title }}</h4>
      <p>{{ feedback.authorName }}</p>
      <p class="card-footer">
        Last Updated: <br />
        {{ new Date(parseInt(feedback.lastUpdatedTs)).toLocaleString() }}
      </p>
    </router-link>
  </li>
</template>

<script>
export default {
  props: {
    feedback: {
      type: Object,
      required: true
    }
  }
};
</script>

<style scoped></style>
