<template>
  <li class="category-preview card">
    <router-link
      :to="'/category/edit/' + category.categoryId"
      class="flex column space-between"
    >
      <img :src="getImgUrl()" />
      <h4>{{ category.categoryName }}</h4>
      <p class="card-footer">
        Last Updated: <br />
        {{ new Date(parseInt(category.lastUpdatedTs)).toLocaleString() }}
      </p>
    </router-link>
  </li>
</template>

<script>
import { imgUrlService } from "@/services/img-url.service.js";
export default {
  props: {
    category: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      imgPrifixUrl: this.$store.getters.imgPrifixUrl
    };
  },
  methods: {
    getImgUrl() {
      return imgUrlService.getImgUrl(this.category.imageUrl, this.imgPrifixUrl);
    }
  }
};
</script>

<style scoped></style>
