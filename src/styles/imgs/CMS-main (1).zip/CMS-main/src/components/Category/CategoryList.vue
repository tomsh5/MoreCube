<template>
  <section class="category-list">
    <router-link to="/category/edit"
      ><button class="btn">Add New Category</button></router-link
    >
    <ul class="flex wrap justify-center">
      <CategoryPreview
        v-for="category in categories"
        :key="category.categoryId"
        :category="category"
      ></CategoryPreview>
    </ul>
  </section>
</template>

<script>
import CategoryPreview from "@/components/Category/CategoryPreview";
export default {
  name: "Category-List",
  props: {
    categories: {
      type: Array,
      required: true
    }
  },
  components: {
    CategoryPreview
  }
};
</script>

<style></style>
