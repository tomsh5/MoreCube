<template>
  <section class="subject-of-interest-list">
    <router-link to="/subjectOfInterest/edit"
      ><button class="btn">Add New Subject Of Interest</button></router-link
    >
    <ul class="flex wrap justify-center">
      <SubjectOfInterestPreview
        v-for="subjectOfInterest in subjectsOfInterest"
        :key="subjectOfInterest.subjectOfInterestId"
        :subjectOfInterest="subjectOfInterest"
      ></SubjectOfInterestPreview>
    </ul>
  </section>
</template>

<script>
import SubjectOfInterestPreview from "@/components/SubjectOfInterest/SubjectOfInterestPreview";
export default {
  name: "Subject-Of-Interest-List",
  props: {
    subjectsOfInterest: {
      type: Array,
      required: true
    }
  },
  components: {
    SubjectOfInterestPreview
  }
};
</script>

<style></style>
