<template>
  <li class="subject-of-interest-preview card">
    <router-link
      :to="'/subjectOfInterest/edit/' + subjectOfInterest.subjectOfInterestId"
      class="flex column space-between"
    >
      <img :src="getImgUrl()" />
      <h4>{{ subjectOfInterest.subjectOfInterestName }}</h4>
      <p class="card-footer">
        Last Updated: <br />
        {{
          new Date(parseInt(subjectOfInterest.lastUpdatedTs)).toLocaleString()
        }}
      </p>
    </router-link>
  </li>
</template>

<script>
import { imgUrlService } from "@/services/img-url.service.js";
export default {
  props: {
    subjectOfInterest: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      imgPrifixUrl: this.$store.getters.imgPrifixUrl
    };
  },
  methods: {
    getImgUrl() {
      return imgUrlService.getImgUrl(
        this.subjectOfInterest.imageUrl,
        this.imgPrifixUrl
      );
    }
  }
};
</script>

<style scoped></style>
