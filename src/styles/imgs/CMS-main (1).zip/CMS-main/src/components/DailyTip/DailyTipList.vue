<template>
  <section class="daily-tip-list">
    <router-link to="/dailyTip/edit"
      ><button class="btn">Add New Daily Tip</button></router-link
    >
    <ul class="flex wrap justify-center">
      <DailyTipPreview v-for="tip in tips" :key="tip.tipId" :tip="tip" />
    </ul>
  </section>
</template>

<script>
import DailyTipPreview from "@/components/DailyTip/DailyTipPreview";
export default {
  name: "Daily-Tip-List",
  props: {
    tips: {
      type: Array,
      required: true
    }
  },
  data() {
    return {};
  },
  components: {
    DailyTipPreview
  }
};
</script>

<style></style>
