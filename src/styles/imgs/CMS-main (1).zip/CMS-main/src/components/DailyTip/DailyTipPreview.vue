<template>
  <li class="daily-tip-preview card">
    <router-link
      :to="'/dailyTip/edit/' + tip.dailyTipId"
      class="flex column space-between"
    >
      <img />
      <h4>{{ tip.subjectTip }}</h4>
      <p class="card-footer">
        Last Updated: <br />
        {{ new Date(parseInt(tip.lastUpdatedTs)).toLocaleString() }}
      </p>
    </router-link>
  </li>
</template>

<script>
export default {
  props: {
    tip: {
      type: Object,
      required: true
    }
  }
};
</script>

<style scoped></style>
