<template>
	<form @submit.prevent class="img-uploader">
		<input type="file" name="file" id="file" />
		<button class="btn" @click="uploadImg()">Upload</button>
	</form>
</template>

<script>
import { imageService } from "@/services/image.service.js";
export default {
	name: "Img-Uploader",
	data() {
		return {
			img: {
				title: "",
				name: "",
				description: "",
				categories: "",
				subjectsOfInterest: "",
				tags: "",
			},
		};
	},
	methods: {
		uploadImg() {
			const imagefile = document.querySelector("#file");
			imageService.uploadImg(imagefile, this.img).then((imageName) => {
				this.$emit("setImg", "{ImagesCDNURL}/" + imageName);
				console.log("imageName:", imageName);
			});
		},
	},
};
</script>

<style lang="scss" scopped>
.img-uploader {
	display: flex;
	justify-content: center;
	align-items: center;
}
</style>
