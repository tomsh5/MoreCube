<template>
	<!--
    To use this component:
    <ImagePickerBox title="Thumb URL" :objUrl="article.thumbUrl" @setImg="article.thumbUrl = $event"/>
    Father component should call when created: this.$store.dispatch({type: 'loadImages'})
 -->
	<div class="image-input labeled-box">
		<label @click="showImages = !showImages">{{ title }}:</label>
		<span @click="showImages = !showImages" v-if="!objUrl || objUrl === ' '">
			Click to Choose
		</span>
		<img
			v-if="objUrl && objUrl !== ' '"
			:src="getImgUrl()"
			@click="showImages = !showImages"
		/>
		<div class="image-box-wraper">
			<div v-if="showImages" class="image-box">
				<button class="btn" v-if="showImages" @click="showImages = false">
					X
				</button>
				<br />
				<img
					v-for="image in this.$store.getters.images"
					:key="image.filename"
					:src="imgPrifixUrl + getImgThumb(image.filename)"
					@click="
						selectImage(image.filename);
						showImages = !showImages;
					"
					:style="
						objUrl ===
							'https://dev1.sexence.com/imagesStub/' + image.filename ||
						objUrl === '{ImagesCDNURL}/' + image.filename
							? `border: 2px black solid`
							: 'border: none'
					"
				/>
			</div>
		</div>
	</div>
</template>

<script>
import { imgUrlService } from "@/services/img-url.service.js";
import { imageService } from "@/services/image.service.js";
export default {
	name: "Image-Input",
	props: {
		title: {
			type: String,
			required: true,
		},
		objUrl: {
			type: String,
			required: false,
		},
	},
	data() {
		return {
			showImages: false,
			imgPrifixUrl: this.$store.getters.imgPrifixUrl,
		};
	},
	methods: {
		getImgUrl() {
			return imgUrlService.getImgUrl(this.objUrl, this.imgPrifixUrl);
		},
		getImgThumb(imgName) {
			return imageService.getImgThumb(imgName);
		},
		selectImage(imageName) {
			this.$emit("setImg", "{ImagesCDNURL}/" + imageName);
		},
	},
};
</script>

<style lang="scss" scopped></style>
