<template>
  <!--
    To use this component:
    <IsLiveInput :val="article.isLive" @setIsLive="article.isLive = $event"/>
    Father component should do nothing special.
 -->
  <div class="is-live-input labeled-box" :class="liveStatus">
    <label>Display: </label>
    <input type="checkbox" v-model="isLive" @change="setIsLive" />
    <span>Visible</span>
  </div>
</template>

<script>
export default {
  name: "Is-Live-Input",
  props: {
    val: {
      Type: Boolean,
      required: true
    }
  },
  data() {
    return {
      isLive: null
    };
  },
  methods: {
    setIsLive() {
      this.$emit("setIsLive", this.isLive);
    }
  },
  computed: {
    liveStatus() {
      return this.val ? "live" : "offline";
    }
  },
  created() {
    this.isLive = this.val;
  }
};
</script>

<style lang="scss" scoped></style>
