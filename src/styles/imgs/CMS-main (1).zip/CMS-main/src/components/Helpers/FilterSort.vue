<template>
  <section class="filter-sort">
    <div class="labeled-field">
      <label>Search</label>
      <input
        type="text"
        placeholder="Enter Title"
        v-model="filterBy.searchStr"
        @input="setFilter"
      />
    </div>
    <div class="labeled-field" v-if="displayCategories">
      <label>Filter Categories</label>
      <select
        placeholder="Select Category"
        v-model="filterBy.categoryId"
        @input="setFilter"
      >
        <option :value="null">All</option>
        <option
          v-for="category in categories"
          :key="category.categoryId"
          :value="category.categoryId"
        >
          {{ category.categoryName }}
        </option>
      </select>
    </div>
    <div class="labeled-field" v-if="displayIsLive">
      <label>Filter On Air</label>
      <select
        placeholder="Select Category"
        v-model="filterBy.isLive"
        @input="setFilter"
      >
        <option :value="null">All</option>
        <option :value="true">Live</option>
        <option :value="false">Offline</option>
      </select>
    </div>
    <div class="labeled-field" v-if="displaySort">
      <label>Sort By</label>
      <select placeholder="Sort" v-model="sortBy" @change="setSort">
        <option v-if="titleToSortBy" :value="titleToSortBy">Title</option>
        <option value="lastUpdated">Last Updated</option>
        <option value="created">Created</option>
        <option v-if="displaySortByPlan" value="dailyPlanNum">
          Plan Number
        </option>
      </select>
    </div>
  </section>
</template>

<script>
export default {
  name: "Filter-Sort",
  props: {
    displayIsLive: {
      Type: Boolean,
      required: false,
      default: false
    },
    displayCategories: {
      Type: Boolean,
      required: false,
      default: false
    },
    displaySort: {
      Type: Boolean,
      required: false,
      default: true
    },
    displaySortByPlan: {
      Type: Boolean,
      required: false,
      default: false
    },
    titleToSortBy: {
      Type: String,
      required: false,
      default: null
    }
  },
  data() {
    return {
      filterBy: {
        searchStr: "",
        categoryId: null,
        isLive: null
      },
      sortBy: null,
      categories: null
    };
  },
  methods: {
    setFilter() {
      this.$store.commit({ type: "setFilterBy", filterBy: this.filterBy });
    },
    setSort() {
      this.$store.commit({ type: "setSortBy", sortBy: this.sortBy });
    }
  },
  async created() {
    const categories = await this.$store.dispatch({ type: "loadCategories" });
    this.categories = categories;
  },
  async destroyed() {
    this.filterBy = {
      searchStr: "",
      categoryId: null,
      isLive: null
    };
    this.$store.commit({ type: "setFilterBy", filterBy: this.filterBy });
  }
};
</script>

<style></style>
