<template>
  <!--
    To use this component:
    <LabeledInput title="Authors Name" :isDisabled="false" :isRequired="true" :val="article.authorName" @setData="article.authorName = $event"/>
    Father component should do nothing special.
 -->
  <div class="labeled-input labeled-field" :class="width">
    <label>{{ title }}:</label
    ><input
      :required="isRequired"
      :disabled="isDisabled"
      :type="type"
      v-model="inputText"
      @input="setData"
      :max="max"
      :min="min"
    />
  </div>
</template>
<script>
export default {
  name: "Labeled-Input",
  props: {
    title: {
      Type: String,
      required: true
    },
    val: {
      Type: String,
      required: true
    },
    isRequired: {
      Type: Boolean,
      required: false,
      default: false
    },
    isDisabled: {
      Type: Boolean,
      required: false,
      default: false
    },
    type: {
      Type: String,
      required: false,
      default: "text"
    },
    max: {
      Type: Number,
      required: false,
      default: null
    },
    min: {
      Type: Number,
      required: false,
      default: null
    },
    width: {
      Type: String,
      required: false,
      default: null
    }
  },
  data() {
    return {
      inputText: null
    };
  },
  methods: {
    setData() {
      this.$emit("setData", this.inputText);
    }
  },
  created() {
    this.inputText = this.val;
  }
};
</script>

<style lang="scss" scopped></style>
