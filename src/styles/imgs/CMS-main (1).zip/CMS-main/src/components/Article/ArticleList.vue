<template>
  <section class="article-list">
    <router-link to="/article/edit"
      ><button class="btn">Add New Article</button></router-link
    >
    <ul class="flex wrap justify-center">
      <ArticlePreview
        v-for="article in articles"
        :key="article.articleId"
        :article="article"
      ></ArticlePreview>
    </ul>
  </section>
</template>

<script>
import ArticlePreview from "@/components/Article/ArticlePreview";
export default {
  name: "Article-List",
  props: {
    articles: {
      type: Array,
      required: true
    }
  },
  components: {
    ArticlePreview
  }
};
</script>

<style lang="scss" scoped></style>
