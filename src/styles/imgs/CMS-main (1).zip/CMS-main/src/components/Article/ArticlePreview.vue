<template>
	<li class="article-preview card">
		<router-link
			:to="'/article/edit/' + article.articleId"
			class="flex column space-between"
		>
			<img :src="getImgUrl()" />
			<h4>{{ article.title }}</h4>
			<p>{{ article.authorName }}</p>
			<p class="card-footer" :class="{ offline: !article.isLive }">
				Last Updated: <br />
				{{ new Date(parseInt(article.lastUpdatedTs)).toLocaleString() }}
			</p>
		</router-link>
	</li>
</template>

<script>
import { imgUrlService } from "@/services/img-url.service.js";
export default {
	props: {
		article: {
			type: Object,
			required: true,
		},
	},
	data() {
		return {
			imgPrifixUrl: this.$store.getters.imgPrifixUrl,
		};
	},
	methods: {
		getImgUrl() {
			return imgUrlService.getImgUrl(this.article.imageUrl, this.imgPrifixUrl);
		},
	},
};
</script>

<style lang="scss" scoped></style>
