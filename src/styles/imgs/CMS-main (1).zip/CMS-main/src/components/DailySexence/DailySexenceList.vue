<template>
  <section class="daily-sexence-list">
    <router-link to="/dailySexence/edit"
      ><button class="btn">Add New Daily Sexence</button></router-link
    >
    <ul class="flex wrap justify-center" v-if="forYous">
      <DailySexencePreview
        v-for="dailySexence in dailySexences"
        :key="dailySexence.dailySexenceId"
        :dailySexence="dailySexence"
        :forYous="forYous"
      />
    </ul>
  </section>
</template>

<script>
import DailySexencePreview from "@/components/DailySexence/DailySexencePreview";
export default {
  name: "Daily-Sexence-List",
  props: {
    dailySexences: {
      type: Array,
      required: true
    }
  },
  data() {
    return {
      forYous: null
    };
  },
  components: {
    DailySexencePreview
  },
  async created() {
    this.forYous = await this.$store.dispatch({ type: "loadForYous" });
  }
};
</script>

<style></style>
