<template>
  <li class="daily-sexence-preview card">
    <router-link
      :to="'/dailySexence/edit/' + dailySexence.dailySexenceId"
      class="flex column space-between"
    >
      <img v-if="forYou" :src="getImgUrl()" />
      <h4>
        {{ dailySexence.title }}
        <br />
        Plan: {{ dailySexence.dailyPlanNum }}
        <br />
        Day: {{ dailySexence.dailyPlanDayNum }}
      </h4>
      <p class="card-footer">
        Last Updated: <br />
        {{ new Date(parseInt(dailySexence.lastUpdatedTs)).toLocaleString() }}
      </p>
    </router-link>
  </li>
</template>

<script>
import { imgUrlService } from "@/services/img-url.service.js";
export default {
  props: {
    dailySexence: {
      type: Object,
      required: true
    },
    forYous: {
      type: Array,
      required: true
    }
  },
  data() {
    return {
      forYou: null,
      imgPrifixUrl: this.$store.getters.imgPrifixUrl
    };
  },
  methods: {
    getImgUrl() {
      return imgUrlService.getImgUrl(
        this.forYou.advisor[0].imageUrl,
        this.imgPrifixUrl
      );
    }
  },
  created() {
    this.forYou = this.forYous.find(
      forYou => forYou.dailyForYouId == this.dailySexence.dailyForYouId
    );
  }
};
</script>

<style scoped></style>
