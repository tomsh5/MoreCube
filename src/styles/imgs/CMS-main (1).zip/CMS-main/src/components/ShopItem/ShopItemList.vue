<template>
  <section class="shop-item-list">
    <router-link to="/shopItem/edit"
      ><button class="btn">Add New Shop Item</button></router-link
    >
    <ul class="flex wrap justify-center">
      <ShopItemPreview
        v-for="shopItem in shopItems"
        :key="shopItem.shopItemId"
        :shopItem="shopItem"
      ></ShopItemPreview>
    </ul>
  </section>
</template>

<script>
import ShopItemPreview from "@/components/ShopItem/ShopItemPreview";
export default {
  name: "Shop-Item-List",
  props: {
    shopItems: {
      type: Array,
      required: true
    }
  },
  components: {
    ShopItemPreview
  }
};
</script>

<style></style>
