<template>
  <section class="daily-for-you-list">
    <router-link to="/dailyForYou/edit"
      ><button class="btn">Add New Daily For You</button></router-link
    >
    <ul class="flex wrap justify-center">
      <DailyForYouPreview
        v-for="forYou in forYous"
        :key="forYou.forYouId"
        :forYou="forYou"
      />
    </ul>
  </section>
</template>

<script>
import DailyForYouPreview from "@/components/DailyForYou/DailyForYouPreview";
export default {
  name: "Daily-For-You-List",
  props: {
    forYous: {
      type: Array,
      required: true
    }
  },
  data() {
    return {};
  },
  components: {
    DailyForYouPreview
  }
};
</script>

<style></style>
