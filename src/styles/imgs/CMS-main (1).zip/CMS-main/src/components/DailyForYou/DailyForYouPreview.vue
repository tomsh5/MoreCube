<template>
  <li class="daily-for-you-preview card">
    <router-link
      :to="'/dailyForYou/edit/' + forYou.dailyForYouId"
      class="flex column space-between"
    >
      <img :src="getImgUrl()" />
      <span v-for="advisor in forYou.advisor" :key="advisor.advisorId">
        <h4>{{ advisor.teaser }}</h4>
      </span>
      <p class="card-footer">
        Last Updated: <br />
        {{ new Date(parseInt(forYou.lastUpdatedTs)).toLocaleString() }}
      </p>
    </router-link>
  </li>
</template>

<script>
import { imgUrlService } from "@/services/img-url.service.js";
export default {
  props: {
    forYou: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      imgPrifixUrl: this.$store.getters.imgPrifixUrl
    };
  },
  methods: {
    getImgUrl() {
      return imgUrlService.getImgUrl(
        this.forYou.advisor[0].imageUrl,
        this.imgPrifixUrl
      );
    }
  }
};
</script>

<style scoped></style>
