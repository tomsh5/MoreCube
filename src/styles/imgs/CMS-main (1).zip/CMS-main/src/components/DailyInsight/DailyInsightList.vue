<template>
  <section class="daily-insight-list">
    <router-link to="/dailyInsight/edit"
      ><button class="btn">Add New Daily Insight</button></router-link
    >
    <ul class="flex wrap justify-center">
      <DailyInsightPreview
        v-for="insight in insights"
        :key="insight.insightId"
        :insight="insight"
      />
    </ul>
  </section>
</template>

<script>
import DailyInsightPreview from "@/components/DailyInsight/DailyInsightPreview";
export default {
  name: "Daily-Insight-List",
  components: { DailyInsightPreview },
  props: {
    insights: {
      type: Array,
      required: true
    }
  }
};
</script>

<style></style>
