<template>
  <li class="daily-insight-preview card">
    <router-link
      :to="'/dailyInsight/edit/' + insight.dailyInsightId"
      class="flex column space-between"
    >
      <img :src="getImgUrl()" />
      <h4>{{ insight.title }}</h4>
      <p class="card-footer">
        Last Updated: <br />
        {{ new Date(parseInt(insight.lastUpdatedTs)).toLocaleString() }}
      </p>
    </router-link>
  </li>
</template>

<script>
import { imgUrlService } from "@/services/img-url.service.js";
export default {
  props: {
    insight: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      imgPrifixUrl: this.$store.getters.imgPrifixUrl
    };
  },
  methods: {
    getImgUrl() {
      return imgUrlService.getImgUrl(this.insight.imageUrl, this.imgPrifixUrl);
    }
  }
};
</script>

<style scoped></style>
