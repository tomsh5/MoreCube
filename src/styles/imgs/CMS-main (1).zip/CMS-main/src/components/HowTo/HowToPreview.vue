<template>
	<li class="how-to-preview card">
		<router-link
			:to="'/howTo/edit/' + howTo.howToId"
			class="flex column space-between"
		>
			<img :src="getImgUrl()" />
			<h4>{{ howTo.title }}</h4>
			<p>{{ howTo.authorName }}</p>
			<p class="card-footer" :class="{ offline: !JSON.parse(howTo.isLive) }">
				Last Updated: <br />
				{{ new Date(parseInt(howTo.lastUpdatedTs)).toLocaleString() }}
			</p>
		</router-link>
	</li>
</template>

<script>
import { imgUrlService } from "@/services/img-url.service.js";
export default {
	props: {
		howTo: {
			type: Object,
			required: true,
		},
	},
	data() {
		return {
			imgPrifixUrl: this.$store.getters.imgPrifixUrl,
		};
	},
	methods: {
		getImgUrl() {
			return imgUrlService.getImgUrl(this.howTo.imageUrl, this.imgPrifixUrl);
		},
	},
};
</script>

<style scoped></style>
