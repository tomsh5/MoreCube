<template>
  <section class="how-to-list">
    <router-link to="/howTo/edit"
      ><button class="btn">Add New How-To</button></router-link
    >
    <ul class="flex wrap justify-center">
      <HowToPreview
        v-for="howTo in howTos"
        :key="howTo.howToId"
        :howTo="howTo"
      ></HowToPreview>
    </ul>
  </section>
</template>

<script>
import HowToPreview from "@/components/HowTo/HowToPreview";
export default {
  name: "How-To-List",
  props: {
    howTos: {
      type: Array,
      required: true
    }
  },
  data() {
    return {};
  },
  components: {
    HowToPreview
  }
};
</script>

<style></style>
