<template>
  <section class="secret-sexence-list">
    <router-link to="/secretSexence/edit"
      ><button class="btn">Add New Secrete Sexence</button></router-link
    >
    <ul class="flex wrap justify-center">
      <SecretSexencePreview
        v-for="secret in secrets"
        :key="secret.secretId"
        :secret="secret"
      ></SecretSexencePreview>
    </ul>
  </section>
</template>

<script>
import SecretSexencePreview from "@/components/SecretSexence/SecretSexencePreview";
export default {
  name: "Secret-Sexence-List",
  props: {
    secrets: {
      type: Array,
      required: true
    }
  },
  data() {
    return {};
  },
  components: {
    SecretSexencePreview
  }
};
</script>

<style></style>
