<template>
  <li class="secret-sexence-preview card" v-if="secret.isLive !== undefined">
    <router-link
      :to="'/secretSexence/edit/' + secret.secretId"
      class="flex column space-between"
    >
      <img :src="getImgUrl()" />
      <h4>{{ secret.question }}</h4>
      <p class="card-footer" :class="{ offline: !JSON.parse(secret.isLive) }">
        Last Updated: <br />
        {{ new Date(parseInt(secret.lastUpdatedTs)).toLocaleString() }}
      </p>
    </router-link>
  </li>
</template>

<script>
import { imgUrlService } from "@/services/img-url.service.js";
export default {
  props: {
    secret: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      imgPrifixUrl: this.$store.getters.imgPrifixUrl
    };
  },
  methods: {
    getImgUrl() {
      return imgUrlService.getImgUrl(this.secret.imageUrl, this.imgPrifixUrl);
    }
  }
};
</script>

<style scoped></style>
